import React from 'react';
import { SurveyAnalyticsDashboard } from '../../survey/SurveyAnalyticsDashboard';
import { Survey, SurveyResponse } from '../../../types/survey';

export interface SurveyAnalyticsProps {
  survey: Survey;
  responses: SurveyResponse[];
  onBack?: () => void;
  onClose?: () => void;
  onRefresh?: () => void;
  onDeleteResponse?: (responseId: string) => void;
  onViewResponseDetail?: (response: SurveyResponse) => void;
}

/**
 * Universal safe Excel / CSV export without external xlsx dependency
 * Uses UTF-8 BOM to guarantee 100% Thai font compatibility in Microsoft Excel.
 */
export const exportSurveyToExcel = (survey: Survey, responses: SurveyResponse[], filename?: string) => {
  if (!responses || responses.length === 0) {
    alert('ยังไม่มีข้อมูลคำตอบสำหรับการส่งออก');
    return;
  }

  const exportRows = responses.map((r, idx) => {
    const rowData: Record<string, any> = {
      'ลำดับ': idx + 1,
      'รหัสคำตอบ': r.id,
      'วันที่ส่ง': new Date(r.submittedAt).toLocaleString('th-TH'),
      'ผู้ตอบ': r.respondentName || 'ไม่ระบุตัวตน (นิรนาม)',
      'ตำแหน่ง': r.respondentPosition || '-',
      'หน่วยงาน/สังกัด': r.respondentDepartment || 'ประชาชน / ทั่วไป',
      'เบอร์โทรศัพท์': r.respondentPhone || '-',
      'อีเมล': r.respondentEmail || '-',
      'เวลาที่ใช้ (วินาที)': r.timeSpentSeconds || '-',
      'คะแนนที่ได้': r.scoreEarned !== undefined ? r.scoreEarned : '-',
      'คะแนนเต็ม': r.totalPossibleScore !== undefined ? r.totalPossibleScore : '-',
      'ผลการประเมิน (%)': r.scorePercentage !== undefined ? `${r.scorePercentage}%` : '-',
      'สถานะการผ่าน': r.isPassed !== undefined ? (r.isPassed ? 'ผ่าน' : 'ไม่ผ่าน') : '-',
      'เลขที่ใบรับรอง': r.certificateNumber || '-'
    };

    survey.questions.forEach((q, qIdx) => {
      if (q.type === 'section_header') return;
      const ans = r.answers[q.id];
      const otherAns = r.answers[`${q.id}_other_text`];

      if (q.type === 'matrix_rating' && q.matrixRows) {
        q.matrixRows.forEach((mRow, mIdx) => {
          const colKey = `ข้อ ${qIdx + 1}.${mIdx + 1}: ${mRow.text}`;
          const rowVal = typeof ans === 'object' && ans ? (ans as Record<string, number>)[mRow.id] : null;
          rowData[colKey] = rowVal !== undefined && rowVal !== null ? rowVal : '-';
        });
      } else if (q.type === 'multiple_choice' || Array.isArray(ans)) {
        const colKey = `ข้อ ${qIdx + 1}: ${q.title}`;
        let valStr = Array.isArray(ans) ? ans.join(', ') : (ans || '-');
        if (otherAns) valStr += ` (อื่นๆ: ${otherAns})`;
        rowData[colKey] = valStr;
      } else if (q.type === 'rating_stars') {
        const colKey = `ข้อ ${qIdx + 1}: ${q.title}`;
        rowData[colKey] = ans !== undefined ? `${ans} ดาว` : '-';
      } else if (q.type === 'slider_score') {
        const colKey = `ข้อ ${qIdx + 1}: ${q.title}`;
        rowData[colKey] = ans !== undefined ? `${ans} คะแนน` : '-';
      } else if (q.type === 'signature') {
        const colKey = `ข้อ ${qIdx + 1}: ${q.title}`;
        rowData[colKey] = ans ? 'มีลายมือชื่อรับรอง' : 'ไม่มี';
      } else {
        const colKey = `ข้อ ${qIdx + 1}: ${q.title}`;
        let valStr = ans !== undefined && ans !== null ? String(ans) : '-';
        if (otherAns) valStr += ` (อื่นๆ: ${otherAns})`;
        rowData[colKey] = valStr;
      }
    });

    return rowData;
  });

  const headers = Array.from(new Set(exportRows.flatMap(row => Object.keys(row))));
  const escapeCsvValue = (val: any) => {
    if (val === null || val === undefined) return '""';
    const str = String(val).replace(/"/g, '""');
    return `"${str}"`;
  };

  const csvLines = [
    headers.map(escapeCsvValue).join(','),
    ...exportRows.map(row => headers.map(h => escapeCsvValue(row[h] ?? '')).join(','))
  ].join('\r\n');

  // Prefix with UTF-8 BOM (\uFEFF) so Excel opens UTF-8 Thai text properly
  const blob = new Blob(['\uFEFF' + csvLines], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename || `survey-results-${survey.id}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

export const exportToExcel = exportSurveyToExcel;
export const exportToCsv = exportSurveyToExcel;

/**
 * SurveyAnalytics View Component
 * Re-exports the high-performance SurveyAnalyticsDashboard
 */
export const SurveyAnalytics: React.FC<SurveyAnalyticsProps> = ({
  survey,
  responses,
  onBack,
  onClose,
  onDeleteResponse
}) => {
  const handleBack = onBack || onClose || (() => {});
  return (
    <SurveyAnalyticsDashboard
      survey={survey}
      responses={responses}
      onBack={handleBack}
      onDeleteResponse={onDeleteResponse}
    />
  );
};

export default SurveyAnalytics;
