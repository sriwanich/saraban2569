import React, { useRef } from 'react';
import { Printer, Download, X, QrCode, Building2, CheckSquare, Circle } from 'lucide-react';
import { Survey } from '../../types/survey';

interface SurveyPrintablePaperModalProps {
  survey: Survey;
  onClose: () => void;
}

export const SurveyPrintablePaperModal: React.FC<SurveyPrintablePaperModalProps> = ({
  survey,
  onClose,
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const isExam = survey.settings.isExamMode || survey.settings.surveyMode === 'exam' || survey.category === 'exam_quiz';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden print:shadow-none print:w-full print:max-w-none">
        {/* Header bar (hidden in print) */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-blue-400" />
            <span className="font-semibold text-base">
              {isExam ? 'กระดาษข้อสอบ / แบบประเมินผลความรู้สำหรับพิมพ์ (A4 Print)' : 'แบบสำรวจฉบับพิมพ์กระดาษ (A4 Paper Print)'}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg text-sm transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              พิมพ์กระดาษ A4 / บันทึก PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Sheet */}
        <div 
          ref={printAreaRef}
          className="p-10 md:p-14 bg-white text-slate-900 font-sans leading-relaxed print:p-0 text-sm"
        >
          {/* Header Banner */}
          <div className="border-b-2 border-slate-900 pb-5 mb-6 flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
                <Building2 className="w-4 h-4" />
                {survey.department || 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง'}
              </div>
              <h1 className="text-xl md:text-2xl font-bold text-slate-900 mb-2">
                {survey.title}
              </h1>
              {survey.description && (
                <p className="text-xs text-slate-600 max-w-2xl leading-normal">
                  <strong>คำชี้แจง:</strong> {survey.description}
                </p>
              )}
            </div>
            {/* Online Response QR Code Prompt */}
            <div className="hidden sm:flex flex-col items-center justify-center p-2.5 border border-slate-300 rounded-lg bg-slate-50 text-center w-28 shrink-0 ml-4 print:flex">
              <QrCode className="w-14 h-14 text-slate-800" />
              <span className="text-[10px] text-slate-600 mt-1 font-medium leading-tight">
                สแกนตอบแบบออนไลน์
              </span>
            </div>
          </div>

          {/* Participant Information Fill-in Box */}
          <div className="border border-slate-300 rounded-lg p-3.5 mb-6 bg-slate-50/70 print:bg-transparent">
            <h3 className="text-xs font-bold text-slate-800 mb-2">
              ส่วนที่ 1: ข้อมูลผู้ตอบแบบสำรวจ / ผู้เข้ารับการทดสอบ
            </h3>
            <div className="grid grid-cols-2 gap-y-3 gap-x-6 text-xs text-slate-700">
              <div className="flex items-baseline gap-2">
                <span className="font-semibold whitespace-nowrap">ชื่อ-นามสกุล:</span>
                <div className="border-b border-dotted border-slate-500 flex-1 h-4" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-semibold whitespace-nowrap">ตำแหน่ง/อาชีพ:</span>
                <div className="border-b border-dotted border-slate-500 flex-1 h-4" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-semibold whitespace-nowrap">หน่วยงาน/สังกัด:</span>
                <div className="border-b border-dotted border-slate-500 flex-1 h-4" />
              </div>
              <div className="flex items-baseline gap-2">
                <span className="font-semibold whitespace-nowrap">เบอร์โทรศัพท์:</span>
                <div className="border-b border-dotted border-slate-500 flex-1 h-4" />
              </div>
            </div>
          </div>

          {/* Questions Section */}
          <div className="space-y-6">
            <div className="text-xs font-bold text-slate-800 border-b border-slate-200 pb-1">
              ส่วนที่ 2: {isExam ? 'ข้อสอบและการประเมินผล' : 'ประเด็นคำถามและการประเมิน'} ({survey.questions.length} ข้อ)
            </div>

            {survey.questions.map((q, idx) => (
              <div key={q.id} className="break-inside-avoid border-b border-slate-100 pb-4">
                <div className="font-semibold text-slate-900 mb-2 flex items-start gap-1">
                  <span>{idx + 1}.</span>
                  <span>{q.title.replace(/^\d+\.\s*/, '')}</span>
                  {q.required && <span className="text-red-500 ml-1">*</span>}
                  {isExam && q.scorePoints && (
                    <span className="ml-2 text-xs font-normal text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                      ({q.scorePoints} คะแนน)
                    </span>
                  )}
                </div>

                {q.description && (
                  <p className="text-xs text-slate-500 mb-2.5 ml-4">{q.description}</p>
                )}

                {/* Choices (Single, Multiple, Picture Choice) */}
                {(q.type === 'single_choice' || q.type === 'multiple_choice' || q.type === 'picture_choice' || q.type === 'dropdown') && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 ml-4 text-xs">
                    {q.options?.map((opt) => (
                      <div key={opt.id} className="flex items-center gap-2 text-slate-700">
                        {q.type === 'single_choice' ? (
                          <div className="w-3.5 h-3.5 rounded-full border border-slate-500 shrink-0" />
                        ) : (
                          <div className="w-3.5 h-3.5 rounded border border-slate-500 shrink-0" />
                        )}
                        <span>{opt.text}</span>
                      </div>
                    ))}
                    {q.allowOther && (
                      <div className="flex items-center gap-2 text-slate-700 md:col-span-2">
                        <div className="w-3.5 h-3.5 rounded border border-slate-500 shrink-0" />
                        <span>อื่นๆ: </span>
                        <div className="border-b border-dotted border-slate-500 flex-1 h-3" />
                      </div>
                    )}
                  </div>
                )}

                {/* Short text */}
                {q.type === 'text_short' && (
                  <div className="ml-4 mt-2">
                    <div className="border-b border-dashed border-slate-400 h-6 max-w-lg" />
                  </div>
                )}

                {/* Long text / Paragraph */}
                {q.type === 'text_long' && (
                  <div className="ml-4 mt-2 space-y-3">
                    <div className="border-b border-dashed border-slate-300 h-5" />
                    <div className="border-b border-dashed border-slate-300 h-5" />
                    <div className="border-b border-dashed border-slate-300 h-5" />
                  </div>
                )}

                {/* Star rating / NPS / Slider */}
                {(q.type === 'rating_stars' || q.type === 'slider_score' || q.type === 'nps_score') && (
                  <div className="ml-4 mt-2 flex items-center gap-3 text-xs">
                    <span className="text-slate-500">น้อยที่สุด</span>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5, ...(q.type === 'nps_score' ? [6, 7, 8, 9, 10] : [])].map(num => (
                        <div key={num} className="flex flex-col items-center gap-1">
                          <div className="w-5 h-5 rounded-full border border-slate-400 flex items-center justify-center text-[10px] font-medium">
                            {num}
                          </div>
                        </div>
                      ))}
                    </div>
                    <span className="text-slate-500">มากที่สุด</span>
                  </div>
                )}

                {/* Matrix rating */}
                {q.type === 'matrix_rating' && (
                  <div className="ml-4 mt-3 overflow-x-auto">
                    <table className="w-full text-xs border border-slate-300 text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-100">
                          <th className="p-2 border border-slate-300 font-semibold">ประเด็นการประเมิน</th>
                          {(q.matrixCols || []).map(col => (
                            <th key={col.id} className="p-2 border border-slate-300 text-center font-medium w-20">
                              {col.text}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(q.matrixRows || []).map(row => (
                          <tr key={row.id}>
                            <td className="p-2 border border-slate-300 text-slate-800">{row.text}</td>
                            {(q.matrixCols || []).map(col => (
                              <td key={col.id} className="p-2 border border-slate-300 text-center">
                                <div className="w-3.5 h-3.5 rounded-full border border-slate-400 mx-auto" />
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Signature box */}
                {q.type === 'signature' && (
                  <div className="ml-4 mt-3 flex justify-end">
                    <div className="w-64 border border-dashed border-slate-400 rounded p-4 text-center">
                      <div className="h-12 border-b border-dotted border-slate-400 mb-2" />
                      <p className="text-[11px] text-slate-500">ลงลายมือชื่อผู้ให้ข้อมูล</p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Footer note */}
          <div className="mt-8 pt-4 border-t border-slate-300 flex justify-between items-center text-[11px] text-slate-500">
            <span>เอกสารแบบสำรวจทางราชการ สำนักงาน ปภ. จังหวัดระยอง</span>
            <span>หน้า 1 / 1</span>
          </div>
        </div>

        {/* Footer actions */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between print:hidden">
          <span>จัดหน้าสำหรับเครื่องพิมพ์ A4 และการแปลงเป็นไฟล์ PDF</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-medium transition-colors"
          >
            ปิด
          </button>
        </div>
      </div>
    </div>
  );
};
