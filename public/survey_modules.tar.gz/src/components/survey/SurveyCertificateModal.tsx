import React, { useRef } from 'react';
import { Award, Download, Printer, X, CheckCircle2, ShieldCheck, QrCode } from 'lucide-react';
import { Survey } from '../../types/survey';
import { formatThaiDate } from '../../types';

interface SurveyCertificateModalProps {
  survey: Survey;
  recipientName: string;
  recipientDepartment?: string;
  scorePercentage: number;
  scoreEarned: number;
  totalPossibleScore: number;
  certificateNumber: string;
  dateStr?: string;
  onClose: () => void;
}

export const SurveyCertificateModal: React.FC<SurveyCertificateModalProps> = ({
  survey,
  recipientName,
  recipientDepartment,
  scorePercentage,
  scoreEarned,
  totalPossibleScore,
  certificateNumber,
  dateStr = new Date().toISOString(),
  onClose,
}) => {
  const certRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const orgName = survey.settings.certificateOrgName || survey.department || 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง';
  const signerName = survey.settings.certificateSignerName || 'หัวหน้าสำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง';
  const signerPosition = survey.settings.certificateSignerPosition || 'ผู้อำนวยการศูนย์บัญชาการเหตุการณ์จังหวัดระยอง';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl overflow-hidden print:shadow-none print:w-full print:max-w-none">
        {/* Header toolbar (Hidden in print) */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 text-white print:hidden">
          <div className="flex items-center gap-2">
            <Award className="w-6 h-6 text-amber-400" />
            <span className="font-semibold text-base">ใบประกาศนียบัตรอิเล็กทรอนิกส์ (e-Certificate of Achievement)</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-medium rounded-lg text-sm transition-colors shadow-sm"
            >
              <Printer className="w-4 h-4" />
              พิมพ์ / บันทึก PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Certificate Printable Canvas */}
        <div 
          ref={certRef}
          className="p-8 md:p-14 bg-gradient-to-b from-amber-50/40 via-white to-amber-50/40 text-center select-none print:p-6"
        >
          {/* Ornate Double Border */}
          <div className="border-4 border-amber-600/70 p-2 rounded-xl">
            <div className="border-2 border-amber-400/60 p-8 md:p-12 rounded-lg bg-white/95 relative overflow-hidden shadow-inner">
              
              {/* Corner Watermarks */}
              <div className="absolute top-2 left-2 w-12 h-12 border-t-2 border-l-2 border-amber-500/80 rounded-tl-lg" />
              <div className="absolute top-2 right-2 w-12 h-12 border-t-2 border-r-2 border-amber-500/80 rounded-tr-lg" />
              <div className="absolute bottom-2 left-2 w-12 h-8 border-b-2 border-l-2 border-amber-500/80 rounded-bl-lg" />
              <div className="absolute bottom-2 right-2 w-12 h-8 border-b-2 border-r-2 border-amber-500/80 rounded-br-lg" />

              {/* Official Seal / Garuda */}
              <div className="flex justify-center mb-4">
                <div className="w-20 h-20 rounded-full bg-amber-50 border-2 border-amber-300 flex items-center justify-center shadow-md">
                  <Award className="w-12 h-12 text-amber-600" />
                </div>
              </div>

              {/* Organization Header */}
              <h2 className="text-xl md:text-2xl font-bold text-slate-800 tracking-wide font-serif mb-1">
                {orgName}
              </h2>
              <p className="text-sm font-medium text-amber-700 uppercase tracking-widest mb-6">
                DEPARTMENT OF DISASTER PREVENTION AND MITIGATION (DDPM)
              </p>

              {/* Certificate Title */}
              <div className="inline-block px-8 py-2 bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 text-white font-bold text-lg md:text-xl rounded-full shadow-md mb-8">
                ใบประกาศนียบัตรรับรองผลการประเมินความรู้
              </div>

              <p className="text-slate-600 text-base mb-3 font-serif">ขอมอบประกาศนียบัตรฉบับนี้เพื่อแสดงว่า</p>

              {/* Recipient Name */}
              <div className="py-2 mb-2 border-b-2 border-amber-300/60 inline-block min-w-[320px]">
                <h3 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
                  {recipientName || 'ผู้เข้ารับการประเมิน'}
                </h3>
                {recipientDepartment && (
                  <p className="text-sm text-slate-600 mt-1 font-medium">สังกัด: {recipientDepartment}</p>
                )}
              </div>

              {/* Achievement Body */}
              <p className="text-slate-700 text-base md:text-lg max-w-2xl mx-auto my-5 leading-relaxed font-serif">
                ได้ผ่านการทดสอบและประเมินผลความรู้ในหลักสูตร
                <br />
                <span className="font-bold text-slate-900 text-lg md:text-xl underline decoration-amber-400 decoration-2 underline-offset-4">
                  "{survey.title}"
                </span>
                <br />
                <span className="text-sm text-slate-600 mt-1 inline-block">
                  ด้วยผลการทดสอบ <strong className="text-emerald-700 text-base">{scorePercentage}%</strong> ({scoreEarned}/{totalPossibleScore} คะแนน) ผ่านเกณฑ์การประเมินมาตรฐาน
                </span>
              </p>

              <p className="text-xs text-slate-500 mt-6 mb-10 font-serif">
                ให้ไว้ ณ วันที่ {formatThaiDate(dateStr)}
              </p>

              {/* Signatures & Security Seals */}
              <div className="flex flex-col md:flex-row items-center justify-between max-w-2xl mx-auto pt-6 border-t border-slate-200 gap-6">
                {/* QR Code Verification */}
                <div className="flex items-center gap-3 text-left">
                  <div className="w-14 h-14 bg-slate-100 border border-slate-300 rounded-lg flex items-center justify-center p-1">
                    <QrCode className="w-10 h-10 text-slate-700" />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      ระบบรับรองดิจิทัล ปภ.
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      เลขที่: {certificateNumber}
                    </div>
                    <div className="text-[9px] text-slate-400">
                      ตรวจยืนยันความถูกต้องผ่านระบบคลาวด์
                    </div>
                  </div>
                </div>

                {/* Director Signature */}
                <div className="text-center">
                  <div className="w-48 h-10 border-b border-dashed border-slate-400 mx-auto flex items-end justify-center pb-1">
                    <span className="font-serif italic text-slate-600 text-sm">{signerName}</span>
                  </div>
                  <p className="text-xs font-semibold text-slate-800 mt-1.5">({signerName})</p>
                  <p className="text-[11px] text-slate-500">{signerPosition}</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between print:hidden">
          <span>ใบประกาศนียบัตรนี้ออกโดยระบบอัตโนมัติของสำนักงาน ปภ. จังหวัดระยอง</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-medium transition-colors"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
