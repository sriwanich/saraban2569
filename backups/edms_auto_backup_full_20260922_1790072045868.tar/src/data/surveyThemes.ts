import { SurveyThemeConfig, SurveySettings } from '../types/survey';

export interface ThemePreset {
  id: string;
  name: string;
  description: string;
  themeColor: string;
  config: SurveyThemeConfig;
}

export const THEME_PRESETS: Record<string, ThemePreset> = {
  thai_gov: {
    id: 'thai_gov',
    name: 'สีกรมท่าราชการ (Thai Royal Navy)',
    description: 'โทนสีสุภาพ เหมาะสำหรับหนังสือราชการและแบบประเมินทางการ',
    themeColor: '#1e3a8a',
    config: {
      presetId: 'thai_gov',
      primaryColor: '#1e3a8a',
      accentColor: '#3b82f6',
      bgColor: '#f8fafc',
      cardBgColor: '#ffffff',
      textColor: '#0f172a',
      fontFamily: 'sarabun',
      borderRadius: 'lg',
      headerStyle: 'solid',
      cardShadow: 'sm',
      buttonStyle: 'filled'
    }
  },
  disaster_alert: {
    id: 'disaster_alert',
    name: 'ส้มเตือนภัย ปภ. (Disaster Alert)',
    description: 'โทนสีส้ม ปภ. สะท้อนการแจ้งเตือนภัยและความพร้อมรับมือ',
    themeColor: '#ea580c',
    config: {
      presetId: 'disaster_alert',
      primaryColor: '#ea580c',
      accentColor: '#f97316',
      bgColor: '#fff7ed',
      cardBgColor: '#ffffff',
      textColor: '#1c1917',
      fontFamily: 'sarabun',
      borderRadius: 'xl',
      headerStyle: 'gradient',
      headerGradientFrom: '#c2410c',
      headerGradientTo: '#ea580c',
      cardShadow: 'md',
      buttonStyle: 'gradient'
    }
  },
  royal_purple: {
    id: 'royal_purple',
    name: 'ม่วงราชสำนัก (Royal Purple)',
    description: 'สง่างาม เหมาะสำหรับพิธีการและการประเมินผู้บริหาร',
    themeColor: '#7c3aed',
    config: {
      presetId: 'royal_purple',
      primaryColor: '#7c3aed',
      accentColor: '#a855f7',
      bgColor: '#faf5ff',
      cardBgColor: '#ffffff',
      textColor: '#1e1b4b',
      fontFamily: 'prompt',
      borderRadius: 'lg',
      headerStyle: 'solid',
      cardShadow: 'sm',
      buttonStyle: 'filled'
    }
  },
  emerald_eco: {
    id: 'emerald_eco',
    name: 'เขียวมรกตสิ่งแวดล้อม (Emerald Eco)',
    description: 'สดชื่น สะอาด เหมาะสำหรับโครงการสิ่งแวดล้อมและ CSR',
    themeColor: '#059669',
    config: {
      presetId: 'emerald_eco',
      primaryColor: '#059669',
      accentColor: '#10b981',
      bgColor: '#f0fdf4',
      cardBgColor: '#ffffff',
      textColor: '#064e3b',
      fontFamily: 'sarabun',
      borderRadius: 'xl',
      headerStyle: 'gradient',
      cardShadow: 'md',
      buttonStyle: 'filled'
    }
  },
  midnight_dark: {
    id: 'midnight_dark',
    name: 'มิดไนท์แบล็ค (Midnight Dark)',
    description: 'โหมดมืดพรีเมียม สบายตาสำหรับใช้งานเวลากลางคืน',
    themeColor: '#0f172a',
    config: {
      presetId: 'midnight_dark',
      primaryColor: '#3b82f6',
      accentColor: '#60a5fa',
      bgColor: '#090d16',
      cardBgColor: '#1e293b',
      textColor: '#f8fafc',
      fontFamily: 'sarabun',
      borderRadius: 'xl',
      headerStyle: 'solid',
      cardShadow: 'glow',
      buttonStyle: 'gradient'
    }
  }
};

export function getMergedThemeConfig(
  themeConfigOrSettings?: SurveySettings | SurveyThemeConfig | null,
  customColor?: string
): SurveyThemeConfig {
  if (!themeConfigOrSettings) {
    return THEME_PRESETS.thai_gov.config;
  }

  // Check if it's a SurveySettings object
  const isSettings = 'themeConfig' in (themeConfigOrSettings as any) || 'status' in (themeConfigOrSettings as any);
  const themeConfig: SurveyThemeConfig | undefined = isSettings 
    ? (themeConfigOrSettings as SurveySettings).themeConfig 
    : (themeConfigOrSettings as SurveyThemeConfig);
  const primaryColor = isSettings 
    ? (themeConfigOrSettings as SurveySettings).themeColor 
    : customColor;

  const preset = themeConfig?.presetId 
    ? THEME_PRESETS[themeConfig.presetId]?.config 
    : THEME_PRESETS.thai_gov.config;

  return {
    ...preset,
    primaryColor: primaryColor || themeConfig?.primaryColor || preset.primaryColor,
    ...themeConfig
  };
}

export function getFontFamilyClass(fontFamily?: string): string {
  switch (fontFamily) {
    case 'prompt':
      return 'font-sans font-prompt';
    case 'kanit':
      return 'font-sans font-kanit';
    case 'sarabun':
    default:
      return 'font-sans font-sarabun';
  }
}

export function getBorderRadiusClass(radius?: string): string {
  switch (radius) {
    case 'none': return 'rounded-none';
    case 'sm': return 'rounded-lg';
    case 'md': return 'rounded-xl';
    case 'lg': return 'rounded-2xl';
    case 'xl': return 'rounded-3xl';
    case 'full': return 'rounded-full';
    default: return 'rounded-2xl';
  }
}

export function getCardShadowClass(shadow?: string): string {
  switch (shadow) {
    case 'none': return 'shadow-none';
    case 'sm': return 'shadow-xs';
    case 'md': return 'shadow-md';
    case 'lg': return 'shadow-xl';
    case 'glow': return 'shadow-2xl shadow-blue-500/10';
    default: return 'shadow-xs';
  }
}
