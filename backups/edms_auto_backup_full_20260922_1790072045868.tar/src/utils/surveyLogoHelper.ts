import { Survey } from '../types/survey';

/**
 * Returns the resolved logo image URL or SVG data URL for surveys based on settings.
 * Overloaded to support both object form and positional parameter form.
 */
export function getResolvedSurveyLogoUrl(
  arg1?: Partial<Survey> | string | null,
  customLogoUrl?: string,
  resolvedLogoUrl?: string
): string {
  if (!arg1) {
    return '/ddpm_logo.png';
  }

  // Handle positional arguments: getResolvedSurveyLogoUrl(headerLogoType, customLogoUrl, resolvedLogoUrl)
  if (typeof arg1 === 'string') {
    const headerLogoType = arg1;
    if (resolvedLogoUrl) return resolvedLogoUrl;
    if (headerLogoType === 'custom' && customLogoUrl) return customLogoUrl;
    if (headerLogoType === 'garuda') return '/garuda_thai_gov.png';
    if (headerLogoType === 'rayong') return '/rayong_provincial_seal.png';
    if (headerLogoType === 'none') return '';
    return '/ddpm_logo.png';
  }

  // Handle object argument: getResolvedSurveyLogoUrl(survey)
  const survey = arg1 as Partial<Survey>;
  if (!survey.settings) {
    return '/ddpm_logo.png';
  }

  const { headerLogoType, customLogoUrl: cUrl, resolvedLogoUrl: rUrl } = survey.settings;

  if (rUrl) {
    return rUrl;
  }

  if (headerLogoType === 'custom' && cUrl) {
    return cUrl;
  }

  if (headerLogoType === 'garuda') {
    return '/garuda_thai_gov.png';
  }

  if (headerLogoType === 'rayong') {
    return '/rayong_provincial_seal.png';
  }

  if (headerLogoType === 'none') {
    return '';
  }

  // Default to DDPM official logo
  return '/ddpm_logo.png';
}

/**
 * Returns system branding info for header and printouts
 */
export function getSystemBrandingInfo() {
  return {
    orgName: 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง',
    systemName: 'ระบบสารบรรณอิเล็กทรอนิกส์และแบบสำรวจอัจฉริยะ',
    agencyName: 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง',
    ministryName: 'กรมป้องกันและบรรเทาสาธารณภัย กระทรวงมหาดไทย',
    officialLogoUrl: '/ddpm_logo.png',
    sealLogoUrl: '/rayong_provincial_seal.png',
    garudaLogoUrl: '/garuda_thai_gov.png'
  };
}

export default getResolvedSurveyLogoUrl;
