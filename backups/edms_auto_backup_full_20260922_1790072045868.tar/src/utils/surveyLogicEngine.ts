import { SurveyQuestion, SurveyLogicRule, SurveyLogicCondition } from '../types/survey';

export interface EvaluatedQuestionState {
  isVisible: boolean;
  isRequired: boolean;
  isReadonly: boolean;
  jumpTargetQuestionId?: string;
  matchedRuleName?: string;
  activeRules: SurveyLogicRule[];
}

/**
 * Checks whether a single condition matches against current answers
 */
export function evaluateCondition(
  condition: SurveyLogicCondition,
  answers: Record<string, any>
): boolean {
  const { triggerQuestionId, operator, triggerValue, matrixRowId } = condition;
  if (!triggerQuestionId) return false;

  let rawAnswer = answers ? answers[triggerQuestionId] : undefined;

  // If this condition is evaluating a specific matrix row
  if (matrixRowId && typeof rawAnswer === 'object' && rawAnswer !== null) {
    rawAnswer = rawAnswer[matrixRowId];
  }

  // Answer state checks
  const isAnswered = rawAnswer !== undefined && rawAnswer !== null && rawAnswer !== '' && (!Array.isArray(rawAnswer) || rawAnswer.length > 0);

  switch (operator) {
    case 'is_answered':
      return isAnswered;

    case 'is_empty':
      return !isAnswered;

    case 'equals':
      if (Array.isArray(rawAnswer)) {
        return rawAnswer.includes(triggerValue);
      }
      return String(rawAnswer) === String(triggerValue);

    case 'not_equals':
      if (Array.isArray(rawAnswer)) {
        return !rawAnswer.includes(triggerValue);
      }
      return String(rawAnswer) !== String(triggerValue);

    case 'contains':
      if (Array.isArray(rawAnswer)) {
        return rawAnswer.includes(triggerValue);
      }
      return String(rawAnswer || '').toLowerCase().includes(String(triggerValue || '').toLowerCase());

    case 'not_contains':
      if (Array.isArray(rawAnswer)) {
        return !rawAnswer.includes(triggerValue);
      }
      return !String(rawAnswer || '').toLowerCase().includes(String(triggerValue || '').toLowerCase());

    case 'greater_than':
      return Number(rawAnswer) > Number(triggerValue);

    case 'greater_than_or_equal':
      return Number(rawAnswer) >= Number(triggerValue);

    case 'less_than':
      return Number(rawAnswer) < Number(triggerValue);

    case 'less_than_or_equal':
      return Number(rawAnswer) <= Number(triggerValue);

    default:
      return false;
  }
}

/**
 * Evaluates whether a logic rule matches
 */
export function evaluateLogicRule(
  rule: SurveyLogicRule,
  answers: Record<string, any>
): boolean {
  if (!rule) return false;

  // Support multi-condition array (SurveyKing standard)
  if (rule.conditions && rule.conditions.length > 0) {
    if (rule.conditionMatch === 'any') {
      return rule.conditions.some(cond => evaluateCondition(cond, answers));
    }
    // Default to 'all' (AND logic)
    return rule.conditions.every(cond => evaluateCondition(cond, answers));
  }

  // Legacy single-condition fallback
  if (rule.triggerQuestionId && rule.operator) {
    return evaluateCondition({
      id: rule.id,
      triggerQuestionId: rule.triggerQuestionId,
      operator: rule.operator as any,
      triggerValue: rule.triggerValue
    }, answers);
  }

  return false;
}

/**
 * Evaluates visibility and required state for a question.
 * Supports both argument order signatures:
 * - evaluateQuestionState(question, answers, allQuestions)
 * - evaluateQuestionState(question, allQuestions, answers)
 */
export function evaluateQuestionState(
  question: SurveyQuestion,
  arg2: Record<string, any> | SurveyQuestion[] = {},
  arg3: Record<string, any> | SurveyQuestion[] = []
): EvaluatedQuestionState {
  let answers: Record<string, any> = {};
  let allQuestions: SurveyQuestion[] = [];

  if (Array.isArray(arg2)) {
    allQuestions = arg2;
    answers = (typeof arg3 === 'object' && !Array.isArray(arg3) ? arg3 : {}) as Record<string, any>;
  } else {
    answers = (arg2 || {}) as Record<string, any>;
    allQuestions = (Array.isArray(arg3) ? arg3 : []) as SurveyQuestion[];
  }

  const result: EvaluatedQuestionState = {
    isVisible: true,
    isRequired: question.required,
    isReadonly: false,
    activeRules: []
  };

  if (!question.logicRules || question.logicRules.length === 0) {
    return result;
  }

  for (const rule of question.logicRules) {
    const isMatched = evaluateLogicRule(rule, answers);

    if (isMatched) {
      result.activeRules.push(rule);
      if (rule.action === 'show') {
        result.isVisible = true;
      } else if (rule.action === 'hide') {
        result.isVisible = false;
      } else if (rule.action === 'require') {
        result.isRequired = true;
      } else if (rule.action === 'jump_to_question') {
        result.jumpTargetQuestionId = rule.targetQuestionId;
      } else if (rule.action === 'jump_to_end') {
        result.jumpTargetQuestionId = '__end__';
      }
      result.matchedRuleName = rule.name;
    }
  }

  return result;
}

/**
 * Generates human-readable Thai description for a logic rule
 */
export function getReadableRuleDescription(
  rule: SurveyLogicRule,
  allQuestions: SurveyQuestion[] = []
): string {
  if (!rule) return '';

  const getQuestionTitle = (qId?: string) => {
    const q = allQuestions.find(item => item.id === qId);
    return q ? `"${q.title.substring(0, 25)}${q.title.length > 25 ? '...' : ''}"` : 'ข้อคำถาม';
  };

  const actionText = 
    rule.action === 'show' ? 'แสดงคำถามนี้' :
    rule.action === 'hide' ? 'ซ่อนคำถามนี้' :
    rule.action === 'require' ? 'บังคับให้ต้องตอบ' :
    rule.action === 'jump_to_question' ? `ข้ามไปยัง ${getQuestionTitle(rule.targetQuestionId)}` :
    rule.action === 'jump_to_end' ? 'ข้ามไปยังหน้าส่งคำตอบ' : 'ดำเนินการ';

  if (rule.conditions && rule.conditions.length > 0) {
    const matchText = rule.conditionMatch === 'any' ? 'ข้อใดข้อหนึ่งถูกต้อง (OR)' : 'ทุกข้อถูกต้อง (AND)';
    return `หาก ${matchText} -> ${actionText}`;
  }

  if (rule.triggerQuestionId) {
    return `หาก ${getQuestionTitle(rule.triggerQuestionId)} ตรงตามเงื่อนไข -> ${actionText}`;
  }

  return actionText;
}
