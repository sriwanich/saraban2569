import React, { useRef, useState } from 'react';
import { 
  Award, 
  Download, 
  Printer, 
  X, 
  CheckCircle2, 
  ShieldCheck, 
  QrCode, 
  Copy, 
  Check, 
  Edit3, 
  Eye, 
  RotateCcw, 
  Settings2, 
  Palette, 
  Sparkles,
  Building2,
  User,
  Calendar,
  FileText,
  Sliders,
  Image as ImageIcon
} from 'lucide-react';
import { Survey } from '../../types/survey';
import { formatThaiDate } from '../../types';
import { getResolvedSurveyLogoUrl } from '../../utils/surveyLogoHelper';

export interface SurveyCertificateModalProps {
  survey: Survey;
  recipientName: string;
  recipientDepartment?: string;
  scorePercentage: number;
  scoreEarned: number;
  totalPossibleScore: number;
  certificateNumber: string;
  dateStr?: string;
  onClose: () => void;
  onSaveDefaults?: (updatedSettings: Partial<Survey['settings']>) => void;
}

export const SurveyCertificateModal: React.FC<SurveyCertificateModalProps> = ({
  survey,
  recipientName: initialRecipientName,
  recipientDepartment: initialRecipientDepartment,
  scorePercentage: initialScorePercentage,
  scoreEarned: initialScoreEarned,
  totalPossibleScore: initialTotalPossibleScore,
  certificateNumber: initialCertNumber,
  dateStr: initialDateStr = new Date().toISOString(),
  onClose,
  onSaveDefaults,
}) => {
  const certRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Editable Certificate State
  const [certTitle, setCertTitle] = useState(
    survey.settings?.certificateTitle || 'ใบประกาศนียบัตรรับรองผลการประเมินความรู้'
  );
  const [certSubtitle, setCertSubtitle] = useState(
    survey.settings?.certificateSubtitle || 'ขอมอบประกาศนียบัตรฉบับนี้เพื่อแสดงว่า'
  );
  const [recipientName, setRecipientName] = useState(initialRecipientName || 'ผู้เข้ารับการประเมิน');
  const [recipientDepartment, setRecipientDepartment] = useState(initialRecipientDepartment || '');
  const [courseName, setCourseName] = useState(
    survey.settings?.certificateCourseName || survey.title
  );
  const [scorePercentage, setScorePercentage] = useState(initialScorePercentage);
  const [scoreEarned, setScoreEarned] = useState(initialScoreEarned);
  const [totalPossibleScore, setTotalPossibleScore] = useState(initialTotalPossibleScore);
  const [showScoreOnCert, setShowScoreOnCert] = useState(true);
  
  const [orgName, setOrgName] = useState(
    survey.settings?.certificateOrgName || survey.department || 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง'
  );
  const [orgSubtitleEn, setOrgSubtitleEn] = useState(
    survey.settings?.certificateOrgSubtitleEn || 'DEPARTMENT OF DISASTER PREVENTION AND MITIGATION (DDPM)'
  );
  const [signerName, setSignerName] = useState(
    survey.settings?.certificateSignerName || 'นายประเสริฐ จิตต์ภักดี'
  );
  const [signerPosition, setSignerPosition] = useState(
    survey.settings?.certificateSignerPosition || 'หัวหน้าสำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง'
  );
  const [certificateNumber, setCertificateNumber] = useState(initialCertNumber);
  const [dateStr, setDateStr] = useState(initialDateStr);
  const [logoType, setLogoType] = useState<'ddpm' | 'garuda' | 'rayong' | 'custom' | 'none'>(
    survey.settings?.certificateLogoType || (survey.settings?.headerLogoType as any) || 'ddpm'
  );
  const [customLogoUrl, setCustomLogoUrl] = useState(
    survey.settings?.certificateCustomLogoUrl || ''
  );
  const [themeStyle, setThemeStyle] = useState<'classic_gold' | 'royal_navy' | 'modern_emerald' | 'crimson_gov' | 'silver_slate'>(
    survey.settings?.certificateTheme || 'classic_gold'
  );
  const [footerNote, setFooterNote] = useState(
    survey.settings?.certificateFooterNote || 'ใบประกาศนียบัตรฉบับนี้ออกด้วยระบบสารบรรณอิเล็กทรอนิกส์ (EDMS) สำนักงาน ปภ. จังหวัดระยอง'
  );

  const handlePrint = () => {
    window.print();
  };

  const handleCopyCertNo = () => {
    if (certificateNumber) {
      navigator.clipboard.writeText(certificateNumber);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleReset = () => {
    setCertTitle(survey.settings?.certificateTitle || 'ใบประกาศนียบัตรรับรองผลการประเมินความรู้');
    setCertSubtitle(survey.settings?.certificateSubtitle || 'ขอมอบประกาศนียบัตรฉบับนี้เพื่อแสดงว่า');
    setRecipientName(initialRecipientName || 'ผู้เข้ารับการประเมิน');
    setRecipientDepartment(initialRecipientDepartment || '');
    setCourseName(survey.settings?.certificateCourseName || survey.title);
    setScorePercentage(initialScorePercentage);
    setScoreEarned(initialScoreEarned);
    setTotalPossibleScore(initialTotalPossibleScore);
    setShowScoreOnCert(true);
    setOrgName(survey.settings?.certificateOrgName || survey.department || 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง');
    setOrgSubtitleEn(survey.settings?.certificateOrgSubtitleEn || 'DEPARTMENT OF DISASTER PREVENTION AND MITIGATION (DDPM)');
    setSignerName(survey.settings?.certificateSignerName || 'นายประเสริฐ จิตต์ภักดี');
    setSignerPosition(survey.settings?.certificateSignerPosition || 'หัวหน้าสำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง');
    setCertificateNumber(initialCertNumber);
    setDateStr(initialDateStr);
    setLogoType(survey.settings?.certificateLogoType || 'ddpm');
    setThemeStyle(survey.settings?.certificateTheme || 'classic_gold');
    setFooterNote(survey.settings?.certificateFooterNote || 'ใบประกาศนียบัตรฉบับนี้ออกด้วยระบบสารบรรณอิเล็กทรอนิกส์ (EDMS) สำนักงาน ปภ. จังหวัดระยอง');
  };

  const handleSaveAsSurveyDefault = () => {
    if (onSaveDefaults) {
      onSaveDefaults({
        certificateTitle: certTitle,
        certificateSubtitle: certSubtitle,
        certificateCourseName: courseName,
        certificateOrgName: orgName,
        certificateOrgSubtitleEn: orgSubtitleEn,
        certificateSignerName: signerName,
        certificateSignerPosition: signerPosition,
        certificateLogoType: logoType,
        certificateCustomLogoUrl: customLogoUrl,
        certificateTheme: themeStyle,
        certificateFooterNote: footerNote
      });
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    }
  };

  // Logo resolver
  const getLogoSrc = () => {
    if (logoType === 'garuda') return '/garuda.png';
    if (logoType === 'rayong') return '/rayong_seal.png';
    if (logoType === 'custom' && customLogoUrl) return customLogoUrl;
    return getResolvedSurveyLogoUrl({ ...survey, settings: { ...survey.settings, headerLogoType: 'ddpm' } }) || '/ddpm_logo.png';
  };

  // Theme color styles
  const getThemeClasses = () => {
    switch (themeStyle) {
      case 'royal_navy':
        return {
          outerBorder: 'border-sky-800',
          innerBorder: 'border-sky-600/70',
          bgGradient: 'from-sky-50/60 via-white to-sky-50/60',
          titleGradient: 'from-sky-700 via-sky-800 to-sky-700',
          accentColor: 'text-sky-900',
          subColor: 'text-sky-700',
          badgeColor: 'bg-sky-700 text-white',
          cornerColor: 'border-sky-700',
          underlineColor: 'decoration-sky-400',
          sealBg: 'bg-sky-50 border-sky-300'
        };
      case 'modern_emerald':
        return {
          outerBorder: 'border-emerald-800',
          innerBorder: 'border-emerald-600/70',
          bgGradient: 'from-emerald-50/60 via-white to-emerald-50/60',
          titleGradient: 'from-emerald-700 via-emerald-800 to-emerald-700',
          accentColor: 'text-emerald-900',
          subColor: 'text-emerald-700',
          badgeColor: 'bg-emerald-700 text-white',
          cornerColor: 'border-emerald-700',
          underlineColor: 'decoration-emerald-400',
          sealBg: 'bg-emerald-50 border-emerald-300'
        };
      case 'crimson_gov':
        return {
          outerBorder: 'border-rose-900',
          innerBorder: 'border-rose-700/70',
          bgGradient: 'from-rose-50/60 via-white to-rose-50/60',
          titleGradient: 'from-rose-800 via-rose-900 to-rose-800',
          accentColor: 'text-rose-950',
          subColor: 'text-rose-800',
          badgeColor: 'bg-rose-800 text-white',
          cornerColor: 'border-rose-800',
          underlineColor: 'decoration-rose-400',
          sealBg: 'bg-rose-50 border-rose-300'
        };
      case 'silver_slate':
        return {
          outerBorder: 'border-slate-700',
          innerBorder: 'border-slate-500/70',
          bgGradient: 'from-slate-50/70 via-white to-slate-50/70',
          titleGradient: 'from-slate-700 via-slate-800 to-slate-700',
          accentColor: 'text-slate-900',
          subColor: 'text-slate-700',
          badgeColor: 'bg-slate-800 text-white',
          cornerColor: 'border-slate-600',
          underlineColor: 'decoration-slate-400',
          sealBg: 'bg-slate-100 border-slate-300'
        };
      case 'classic_gold':
      default:
        return {
          outerBorder: 'border-amber-600/80',
          innerBorder: 'border-amber-400/60',
          bgGradient: 'from-amber-50/60 via-white to-amber-50/60',
          titleGradient: 'from-amber-500 via-amber-600 to-amber-500',
          accentColor: 'text-slate-800',
          subColor: 'text-amber-800',
          badgeColor: 'bg-amber-600 text-white',
          cornerColor: 'border-amber-500/80',
          underlineColor: 'decoration-amber-400',
          sealBg: 'bg-amber-50 border-amber-300'
        };
    }
  };

  const themeClasses = getThemeClasses();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-2 sm:p-4 md:p-6 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="relative w-full max-w-5xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl overflow-hidden print:shadow-none print:w-full print:max-w-none flex flex-col max-h-[92vh]">
        
        {/* Top Header Toolbar (Hidden in print) */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 bg-slate-900 text-white print:hidden shrink-0 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-sm sm:text-base block">ใบประกาศนียบัตรอิเล็กทรอนิกส์ (e-Certificate)</span>
              <span className="text-[11px] text-slate-400">ระบบประเมินผลความรู้มาตรฐาน ปภ. จังหวัดระยอง</span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Toggle Edit Details Mode */}
            <button
              onClick={() => setIsEditing(!isEditing)}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                isEditing 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
              title="แก้ไขข้อความ ชื่อผู้รับ หรือรายละเอียดในใบประกาศฯ"
            >
              {isEditing ? <Eye className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5 text-blue-400" />}
              <span>{isEditing ? 'ดูตัวอย่างจริง' : 'แก้ไขรายละเอียดข้อมูล'}</span>
            </button>

            <button
              onClick={handleCopyCertNo}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium rounded-xl text-xs transition-colors border border-slate-700 cursor-pointer"
              title="คัดลอกเลขที่ใบประกาศฯ"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? 'คัดลอกแล้ว' : 'คัดลอกเลขที่'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>พิมพ์ / บันทึก PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area: Split View when editing, or Full View */}
        <div className="flex-1 overflow-y-auto flex flex-col lg:flex-row divide-y lg:divide-y-0 lg:divide-x divide-slate-200 dark:divide-slate-800">
          
          {/* EDIT DRAWER / FORM (Visible when isEditing = true) */}
          {isEditing && (
            <div className="w-full lg:w-96 bg-slate-50 dark:bg-slate-950 p-5 overflow-y-auto shrink-0 print:hidden space-y-4 text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
                <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-sm">
                  <Sliders className="w-4 h-4 text-blue-600" /> ปรับแต่งข้อมูลในใบประกาศฯ
                </span>
                <button
                  onClick={handleReset}
                  className="text-[11px] text-slate-500 hover:text-rose-600 flex items-center gap-1 cursor-pointer"
                  title="คืนค่าข้อมูลเริ่มต้น"
                >
                  <RotateCcw className="w-3 h-3" /> รีเซ็ต
                </button>
              </div>

              {/* Theme & Styling */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-purple-600" /> โทนสีและสไตล์กรอบ
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  {[
                    { id: 'classic_gold', label: 'ทองอร่าม (Classic Gold)', color: 'bg-amber-500' },
                    { id: 'royal_navy', label: 'น้ำเงินกรมท่า (Royal Navy)', color: 'bg-sky-700' },
                    { id: 'modern_emerald', label: 'เขียวมรกต (Emerald)', color: 'bg-emerald-600' },
                    { id: 'crimson_gov', label: 'แดงเลือดหมู (Crimson Gov)', color: 'bg-rose-700' },
                    { id: 'silver_slate', label: 'เงินพรีเมียม (Silver Slate)', color: 'bg-slate-700' },
                  ].map(th => (
                    <button
                      key={th.id}
                      type="button"
                      onClick={() => setThemeStyle(th.id as any)}
                      className={`p-2 rounded-xl border text-left flex items-center gap-2 cursor-pointer transition ${
                        themeStyle === th.id
                          ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/50 font-bold text-blue-900 dark:text-blue-300'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      <span className={`w-3 h-3 rounded-full shrink-0 ${th.color}`} />
                      <span className="truncate text-[11px]">{th.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Logo Select */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <ImageIcon className="w-3.5 h-3.5 text-amber-600" /> ตราสัญลักษณ์ส่วนบน
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'ddpm', label: 'ตรา ปภ.' },
                    { id: 'garuda', label: 'ตราครุฑราชการ' },
                    { id: 'rayong', label: 'ตราจังหวัดระยอง' },
                  ].map(lg => (
                    <button
                      key={lg.id}
                      type="button"
                      onClick={() => setLogoType(lg.id as any)}
                      className={`p-1.5 rounded-xl border text-center font-bold text-[11px] cursor-pointer transition ${
                        logoType === lg.id
                          ? 'border-blue-600 bg-blue-50 dark:bg-blue-950 text-blue-800 dark:text-blue-300'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {lg.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Recipient Details */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-blue-600" /> ข้อมูลผู้รับใบประกาศฯ
                </label>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ชื่อ-นามสกุล (พร้อมคำนำหน้า):</span>
                  <input
                    type="text"
                    value={recipientName}
                    onChange={(e) => setRecipientName(e.target.value)}
                    className="w-full p-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-bold text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">สังกัด / หน่วยงานผู้รับ:</span>
                  <input
                    type="text"
                    value={recipientDepartment}
                    onChange={(e) => setRecipientDepartment(e.target.value)}
                    placeholder="เช่น สำนักงาน ปภ. จังหวัดระยอง, ประชาชนทั่วไป"
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-800 dark:text-slate-200"
                  />
                </div>
              </div>

              {/* Certificate Titles & Content */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-emerald-600" /> ข้อความและหลักสูตร
                </label>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">หัวเรื่องใบประกาศฯ:</span>
                  <input
                    type="text"
                    value={certTitle}
                    onChange={(e) => setCertTitle(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">คำโปรยแสดงความยินดี:</span>
                  <input
                    type="text"
                    value={certSubtitle}
                    onChange={(e) => setCertSubtitle(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ชื่อหลักสูตร / การทดสอบ:</span>
                  <textarea
                    rows={2}
                    value={courseName}
                    onChange={(e) => setCourseName(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl leading-relaxed"
                  />
                </div>
              </div>

              {/* Score Display Options */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-700 dark:text-slate-300">แสดงคะแนนการทดสอบ:</span>
                  <input
                    type="checkbox"
                    checked={showScoreOnCert}
                    onChange={(e) => setShowScoreOnCert(e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded"
                  />
                </div>
                {showScoreOnCert && (
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <span className="text-[10px] text-slate-500 block">คะแนน (%)</span>
                      <input
                        type="number"
                        value={scorePercentage}
                        onChange={(e) => setScorePercentage(Number(e.target.value))}
                        className="w-full p-1.5 text-center font-mono font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">ได้คะแนน</span>
                      <input
                        type="number"
                        value={scoreEarned}
                        onChange={(e) => setScoreEarned(Number(e.target.value))}
                        className="w-full p-1.5 text-center font-mono font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block">คะแนนเต็ม</span>
                      <input
                        type="number"
                        value={totalPossibleScore}
                        onChange={(e) => setTotalPossibleScore(Number(e.target.value))}
                        className="w-full p-1.5 text-center font-mono font-bold bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Organization & Signer */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-amber-600" /> หน่วยงานและผู้ลงนาม
                </label>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ชื่อหน่วยงาน (ภาษาไทย):</span>
                  <input
                    type="text"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-medium"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ชื่อหน่วยงาน (ภาษาอังกฤษ):</span>
                  <input
                    type="text"
                    value={orgSubtitleEn}
                    onChange={(e) => setOrgSubtitleEn(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px] font-mono"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ชื่อผู้ลงนาม:</span>
                  <input
                    type="text"
                    value={signerName}
                    onChange={(e) => setSignerName(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">ตำแหน่งผู้ลงนาม:</span>
                  <input
                    type="text"
                    value={signerPosition}
                    onChange={(e) => setSignerPosition(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-[11px]"
                  />
                </div>
              </div>

              {/* Number & Date */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <label className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" /> เลขที่และวันที่ออก
                </label>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">เลขที่ใบประกาศนียบัตร:</span>
                  <input
                    type="text"
                    value={certificateNumber}
                    onChange={(e) => setCertificateNumber(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl font-mono"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-slate-500 mb-1 block">วันที่ออกเอกสาร:</span>
                  <input
                    type="date"
                    value={dateStr ? dateStr.substring(0, 10) : ''}
                    onChange={(e) => setDateStr(e.target.value ? new Date(e.target.value).toISOString() : dateStr)}
                    className="w-full p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
                  />
                </div>
              </div>

              {/* Save as default button */}
              {onSaveDefaults && (
                <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={handleSaveAsSurveyDefault}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>บันทึกการตั้งค่านี้เป็นค่าเริ่มต้นของแบบสำรวจ</span>
                  </button>
                  {savedSuccess && (
                    <div className="text-[11px] text-emerald-600 font-bold text-center mt-1.5 flex items-center justify-center gap-1">
                      <Check className="w-3.5 h-3.5" /> บันทึกการตั้งค่าแบบสำรวจเรียบร้อย
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Certificate Printable Canvas */}
          <div className="flex-1 p-4 sm:p-8 bg-slate-100 dark:bg-slate-950/60 flex items-center justify-center overflow-x-auto print:p-0 print:bg-white">
            <div 
              ref={certRef}
              className={`w-full max-w-4xl p-6 md:p-10 bg-gradient-to-b ${themeClasses.bgGradient} text-center select-none print:p-6 rounded-2xl shadow-sm border border-slate-200/80 dark:border-slate-700/80 bg-white`}
            >
              {/* Ornate Double Border */}
              <div className={`border-4 ${themeClasses.outerBorder} p-2.5 rounded-2xl`}>
                <div className={`border-2 ${themeClasses.innerBorder} p-6 md:p-10 rounded-xl bg-white/95 relative overflow-hidden shadow-inner`}>
                  
                  {/* Corner Watermarks */}
                  <div className={`absolute top-2 left-2 w-12 h-12 border-t-2 border-l-2 ${themeClasses.cornerColor} rounded-tl-lg`} />
                  <div className={`absolute top-2 right-2 w-12 h-12 border-t-2 border-r-2 ${themeClasses.cornerColor} rounded-tr-lg`} />
                  <div className={`absolute bottom-2 left-2 w-12 h-8 border-b-2 border-l-2 ${themeClasses.cornerColor} rounded-bl-lg`} />
                  <div className={`absolute bottom-2 right-2 w-12 h-8 border-b-2 border-r-2 ${themeClasses.cornerColor} rounded-br-lg`} />

                  {/* Official Seal */}
                  <div className="flex justify-center mb-3">
                    <div className={`w-20 h-20 rounded-full ${themeClasses.sealBg} flex items-center justify-center p-2 shadow-md`}>
                      <img 
                        src={getLogoSrc()} 
                        alt="Official Seal" 
                        className="w-full h-full object-contain"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                  </div>

                  {/* Organization Header */}
                  <h2 className={`text-lg md:text-2xl font-bold ${themeClasses.accentColor} tracking-wide font-serif mb-1`}>
                    {orgName}
                  </h2>
                  {orgSubtitleEn && (
                    <p className={`text-[10px] md:text-xs font-semibold ${themeClasses.subColor} uppercase tracking-widest mb-5`}>
                      {orgSubtitleEn}
                    </p>
                  )}

                  {/* Certificate Title Banner */}
                  <div className={`inline-block px-8 py-2 bg-gradient-to-r ${themeClasses.titleGradient} text-white font-bold text-sm md:text-lg rounded-full shadow-md mb-5`}>
                    {certTitle}
                  </div>

                  <p className="text-slate-600 text-xs md:text-sm mb-2 font-serif">{certSubtitle}</p>

                  {/* Recipient Name */}
                  <div className="py-1.5 mb-2 border-b-2 border-amber-300/80 inline-block min-w-[280px] sm:min-w-[360px]">
                    <h3 className="text-xl md:text-3xl font-extrabold text-slate-900 tracking-tight">
                      {recipientName}
                    </h3>
                    {recipientDepartment && (
                      <p className="text-xs sm:text-sm text-slate-600 mt-1 font-medium">สังกัด: {recipientDepartment}</p>
                    )}
                  </div>

                  {/* Achievement Body */}
                  <div className="text-slate-700 text-xs md:text-sm max-w-2xl mx-auto my-3 leading-relaxed font-serif">
                    ได้ผ่านการทดสอบและประเมินผลความรู้ในหลักสูตร
                    <div className={`my-1.5 font-bold text-slate-900 text-sm md:text-lg underline ${themeClasses.underlineColor} decoration-2 underline-offset-4`}>
                      "{courseName}"
                    </div>
                    {showScoreOnCert && (
                      <div className="text-xs text-slate-600 mt-2">
                        ด้วยผลการทดสอบ <strong className="text-emerald-700 text-sm md:text-base font-bold font-mono">{scorePercentage}%</strong> ({scoreEarned}/{totalPossibleScore} คะแนน) ผ่านเกณฑ์การประเมินมาตรฐาน
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-500 mt-4 mb-7 font-serif">
                    ให้ไว้ ณ วันที่ {formatThaiDate(dateStr)}
                  </p>

                  {/* Signatures & Security Seals */}
                  <div className="flex flex-col md:flex-row items-center justify-between max-w-2xl mx-auto pt-4 border-t border-slate-200 gap-4">
                    {/* QR Code Verification */}
                    <div className="flex items-center gap-2.5 text-left">
                      <div className="w-12 h-12 bg-slate-100 border border-slate-300 rounded-lg flex items-center justify-center p-1 shrink-0">
                        <QrCode className="w-8 h-8 text-slate-700" />
                      </div>
                      <div>
                        <div className="text-[11px] font-semibold text-slate-700 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          ระบบรับรองดิจิทัล ปภ.
                        </div>
                        <div className="text-[10px] text-slate-600 font-mono font-bold">
                          เลขที่: {certificateNumber}
                        </div>
                        <div className="text-[9px] text-slate-400">
                          ตรวจยืนยันความถูกต้องผ่านระบบคลาวด์
                        </div>
                      </div>
                    </div>

                    {/* Director Signature */}
                    <div className="text-center">
                      <div className="w-44 sm:w-52 h-9 border-b border-dashed border-slate-400 mx-auto flex items-end justify-center pb-1">
                        <span className="font-serif italic text-slate-700 text-sm font-semibold">{signerName}</span>
                      </div>
                      <p className="text-xs font-semibold text-slate-800 mt-1">({signerName})</p>
                      <p className="text-[10px] text-slate-500">{signerPosition}</p>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 flex items-center justify-between print:hidden shrink-0">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {footerNote}
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
};
