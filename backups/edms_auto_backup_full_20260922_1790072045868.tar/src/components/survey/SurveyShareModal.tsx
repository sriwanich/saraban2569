import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  QrCode, 
  Download, 
  Share2, 
  Code, 
  ExternalLink, 
  FileText, 
  Printer, 
  Sparkles,
  Link,
  Shield,
  Send,
  Smartphone,
  CheckCircle2,
  Lock,
  Globe
} from 'lucide-react';
import QRCode from 'qrcode';
import { Survey } from '../../types/survey';

interface SurveyShareModalProps {
  survey: Survey;
  onClose: () => void;
  onLinkToEdms?: (survey: Survey) => void;
}

export const SurveyShareModal: React.FC<SurveyShareModalProps> = ({
  survey,
  onClose,
  onLinkToEdms,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedEmbed, setCopiedEmbed] = useState(false);
  const [copiedShortUrl, setCopiedShortUrl] = useState(false);
  const [activeTab, setActiveTab] = useState<'link' | 'qr' | 'embed' | 'edms'>('link');
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);

  const baseUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const surveyShareUrl = `${baseUrl}/public/survey/${survey.id}`;
  const embedCodeSnippet = `<iframe src="${surveyShareUrl}?embed=true" width="100%" height="800" frameborder="0" style="border:0; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.08);" allow="camera; microphone; geolocation"></iframe>`;

  useEffect(() => {
    generateQr();
  }, [survey.id, survey.settings?.themeColor]);

  const generateQr = async () => {
    try {
      const canvas = qrCanvasRef.current;
      if (!canvas) return;

      const primaryColor = survey.settings?.themeColor || '#2563eb';
      
      await QRCode.toCanvas(canvas, surveyShareUrl, {
        width: 340,
        margin: 2,
        color: {
          dark: primaryColor,
          light: '#ffffff'
        },
        errorCorrectionLevel: 'H'
      });
    } catch (err) {
      console.error('Error generating QR code:', err);
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(surveyShareUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // Fallback
      const input = document.createElement('input');
      input.value = surveyShareUrl;
      document.body.appendChild(input);
      input.select();
      document.execCommand('copy');
      document.body.removeChild(input);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleCopyEmbed = async () => {
    try {
      await navigator.clipboard.writeText(embedCodeSnippet);
      setCopiedEmbed(true);
      setTimeout(() => setCopiedEmbed(false), 2500);
    } catch {
      setCopiedEmbed(true);
      setTimeout(() => setCopiedEmbed(false), 2500);
    }
  };

  const handleDownloadQr = () => {
    const canvas = qrCanvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `QR-Survey-${survey.title.substring(0, 30)}-${survey.id}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const handleShareLine = () => {
    const lineUrl = `https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(surveyShareUrl)}&text=${encodeURIComponent(`ขอเชิญร่วมตอบแบบสำรวจ: ${survey.title}`)}`;
    window.open(lineUrl, '_blank');
  };

  const handleShareFacebook = () => {
    const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(surveyShareUrl)}`;
    window.open(fbUrl, '_blank');
  };

  const isPasswordProtected = Boolean(survey.settings?.passwordProtection);
  const isPublished = survey.settings?.status === 'published';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white dark:from-slate-900 dark:via-blue-950/20 dark:to-slate-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30">
              <Share2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                แชร์และเผยแพร่แบบสำรวจ
                <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full ${
                  isPublished 
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800' 
                    : 'bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                }`}>
                  {isPublished ? '● เผยแพร่อยู่' : '○ ฉบับร่าง'}
                </span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1 max-w-md">
                {survey.title}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 gap-2 bg-slate-50/50 dark:bg-slate-900/50">
          {[
            { id: 'link', label: 'ลิงก์และโซเชียล', icon: Link },
            { id: 'qr', label: 'QR Code สำหรับพิมพ์/สแกน', icon: QrCode },
            { id: 'embed', label: 'ฝังลงเว็บไซต์ (Embed)', icon: Code },
            { id: 'edms', label: 'เชื่อมโยงเอกสารสารบรรณ', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-4 text-xs font-semibold border-b-2 transition whitespace-nowrap ${
                  isActive
                    ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-white dark:bg-slate-800/60 rounded-t-xl'
                    : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* TAB 1: Link & Social Share */}
          {activeTab === 'link' && (
            <div className="space-y-6 animate-fade-in">
              {/* Direct Link Box */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  ลิงก์สำหรับผู้ตอบแบบสำรวจ (Direct Survey URL)
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex-1 relative flex items-center">
                    <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 pointer-events-none" />
                    <input
                      type="text"
                      readOnly
                      value={surveyShareUrl}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-700 dark:text-slate-200 font-mono focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm whitespace-nowrap ${
                      copiedLink
                        ? 'bg-emerald-600 text-white'
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                  >
                    {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedLink ? 'คัดลอกแล้ว!' : 'คัดลอกลิงก์'}</span>
                  </button>
                  <a
                    href={surveyShareUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded-xl transition"
                    title="เปิดหน้าแบบสำรวจในแท็บใหม่"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>

              {/* Security & Access Notice */}
              <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                  <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span>การตั้งค่าความปลอดภัยและการเข้าถึง</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600 dark:text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                    <span>ตอบแบบนิรนาม: {survey.settings?.allowAnonymous ? 'อนุญาต (ไม่ระบุตัวตน)' : 'ต้องระบุชื่อ/สังกัด'}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                    <span>การจำกัด: {survey.settings?.limitOneResponsePerDevice ? '1 ครั้งต่ออุปกรณ์' : 'ตอบได้หลายครั้ง'}</span>
                  </div>
                  {isPasswordProtected && (
                    <div className="flex items-center gap-1.5 text-amber-600 dark:text-amber-400 font-medium">
                      <Lock className="w-3 h-3" />
                      <span>มีการตั้งรหัสผ่านป้องกัน</span>
                    </div>
                  )}
                  {survey.settings?.endDate && (
                    <div className="flex items-center gap-1.5 text-slate-500">
                      <span>สิ้นสุดรับคำตอบ: {new Date(survey.settings.endDate).toLocaleDateString('th-TH')}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Social Share Buttons */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  แชร์ไปยังแอปพลิเคชันและกลุ่มงาน
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <button
                    type="button"
                    onClick={handleShareLine}
                    className="flex items-center justify-center gap-2 p-3 bg-emerald-500 hover:bg-emerald-600 text-white rounded-2xl text-xs font-bold transition shadow-sm"
                  >
                    <span>แชร์เข้า LINE</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleShareFacebook}
                    className="flex items-center justify-center gap-2 p-3 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-xs font-bold transition shadow-sm"
                  >
                    <span>Facebook</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const mailto = `mailto:?subject=${encodeURIComponent(`ขอเชิญตอบแบบสำรวจ: ${survey.title}`)}&body=${encodeURIComponent(`เรียน ทุกท่าน\n\nขอความอนุเคราะห์ร่วมตอบแบบสำรวจ "${survey.title}"\nได้ที่ลิงก์: ${surveyShareUrl}\n\nสำนักงาน ปภ. จังหวัดระยอง`)}`;
                      window.location.href = mailto;
                    }}
                    className="flex items-center justify-center gap-2 p-3 bg-slate-700 hover:bg-slate-800 text-white rounded-2xl text-xs font-bold transition shadow-sm"
                  >
                    <span>ส่งทาง Email</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="flex items-center justify-center gap-2 p-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-2xl text-xs font-bold transition"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>คัดลอก URL</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: QR Code */}
          {activeTab === 'qr' && (
            <div className="space-y-6 text-center animate-fade-in">
              <div className="p-6 bg-slate-50 dark:bg-slate-800/40 rounded-3xl border border-slate-200 dark:border-slate-800 inline-block mx-auto shadow-sm">
                <div className="bg-white p-4 rounded-2xl shadow-md inline-block border border-slate-100">
                  <canvas ref={qrCanvasRef} className="max-w-[240px] h-auto mx-auto" />
                </div>
                <div className="mt-4 text-xs font-bold text-slate-700 dark:text-slate-300">
                  {survey.title}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  สแกนด้วยสมาร์ทโฟนเพื่อเข้าสู่แบบประเมินทันที
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={handleDownloadQr}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-blue-500/20"
                >
                  <Download className="w-4 h-4" />
                  <span>ดาวน์โหลดภาพ QR Code (PNG คมชัดสูง)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const canvas = qrCanvasRef.current;
                    if (!canvas) return;
                    const win = window.open('', '_blank');
                    if (!win) return;
                    win.document.write(`
                      <html>
                        <head>
                          <title>QR Code - ${survey.title}</title>
                          <style>
                            body { font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
                            .card { border: 2px solid #e2e8f0; padding: 32px; border-radius: 24px; text-align: center; max-width: 400px; }
                            h2 { margin-top: 16px; font-size: 18px; }
                            p { font-size: 13px; color: #64748b; }
                          </style>
                        </head>
                        <body>
                          <div class="card">
                            <img src="${canvas.toDataURL('image/png')}" width="280" />
                            <h2>${survey.title}</h2>
                            <p>สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง</p>
                          </div>
                          <script>window.onload = () => { window.print(); };</script>
                        </body>
                      </html>
                    `);
                    win.document.close();
                  }}
                  className="px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-2"
                >
                  <Printer className="w-4 h-4" />
                  <span>พิมพ์ใบสแกน QR Code</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: Embed Code */}
          {activeTab === 'embed' && (
            <div className="space-y-4 animate-fade-in">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  โค้ด HTML iFrame สำหรับนำไปฝังบนเว็บไซต์หรือ Portal หน่วยงาน
                </label>
                <p className="text-[11px] text-slate-500 mb-2">
                  คัดลอกโค้ดด้านล่างไปวางในเว็บไซต์ WordPress, ระบบ Intranet, หรือหน้าเว็บสาธารณะ
                </p>
                <div className="relative">
                  <textarea
                    rows={4}
                    readOnly
                    value={embedCodeSnippet}
                    className="w-full p-3.5 bg-slate-900 text-emerald-400 font-mono text-xs rounded-2xl border border-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/30"
                  />
                  <button
                    type="button"
                    onClick={handleCopyEmbed}
                    className="absolute top-3 right-3 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium transition flex items-center gap-1.5 border border-slate-700"
                  >
                    {copiedEmbed ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedEmbed ? 'คัดลอกแล้ว' : 'คัดลอกโค้ด'}</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-2xl border border-blue-200 dark:border-blue-900/50 text-xs text-blue-800 dark:text-blue-300">
                <div className="font-bold mb-1 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>ข้อแนะนำการฝังฟอร์ม</span>
                </div>
                <p className="text-[11px] leading-relaxed text-blue-700 dark:text-blue-300/90">
                  โค้ดฝังข้างต้นรองรับการทำงานแบบ Responsive เต็มรูปแบบ ปรับขนาดตามหน้าจอของผู้ชมโดยอัตโนมัติ และอนุญาตให้ใช้งานระบบอัปโหลดไฟล์ ลายมือชื่อ และ GPS
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: EDMS Link */}
          {activeTab === 'edms' && (
            <div className="space-y-4 animate-fade-in">
              <div className="p-4 bg-indigo-50 dark:bg-indigo-950/30 rounded-2xl border border-indigo-200 dark:border-indigo-900/50">
                <div className="flex items-center gap-2 font-bold text-xs text-indigo-900 dark:text-indigo-200 mb-1">
                  <FileText className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  <span>เชื่อมโยงผลแบบสำรวจเข้ากับหนังสือราชการ e-Saraban</span>
                </div>
                <p className="text-[11px] text-indigo-700 dark:text-indigo-300/80 leading-relaxed">
                  สามารถเชื่อมโยงแบบประเมินนี้เข้ากับหนังสือเวียน บันทึกข้อความ หรือรายงานสรุปผล เพื่อให้อนุญาตแนบ QR Code ในเอกสารและติดตามผลตอบรับได้ทันที
                </p>
              </div>

              {onLinkToEdms ? (
                <button
                  type="button"
                  onClick={() => {
                    onLinkToEdms(survey);
                    onClose();
                  }}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20"
                >
                  <FileText className="w-4 h-4" />
                  <span>เลือกหนังสือราชการเพื่อเชื่อมโยงแบบสำรวจ</span>
                </button>
              ) : (
                <div className="text-center p-6 text-xs text-slate-500">
                  ท่านสามารถแนบ QR Code ของแบบสำรวจนี้ในขั้นตอนออกหนังสือราชการหรือหนังสือเวียนได้โดยตรง
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 flex items-center justify-between">
          <div className="text-[11px] text-slate-400">
            ID: <span className="font-mono text-slate-600 dark:text-slate-300">{survey.id}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition"
          >
            ปิดหน้าต่าง
          </button>
        </div>

      </div>
    </div>
  );
};

export default SurveyShareModal;
