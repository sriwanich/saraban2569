import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  Save, 
  Plus, 
  Trash2, 
  GripVertical, 
  Settings, 
  Eye, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  Copy, 
  CheckCircle2,
  Type, 
  AlignLeft, 
  List, 
  CheckSquare, 
  Star, 
  LayoutGrid, 
  Sliders, 
  Calendar, 
  FileUp, 
  Hash, 
  FileEdit,
  Smartphone,
  Tablet,
  Monitor,
  Palette,
  GitBranch,
  Award,
  Layers,
  HelpCircle,
  Clock,
  Shield,
  Upload,
  Check,
  X,
  MapPin,
  Phone,
  FileText,
  AlertCircle,
  Wand2,
  Share2
} from 'lucide-react';
import { 
  Survey, 
  SurveyQuestion, 
  SurveySettings, 
  SurveyQuestionType,
  SurveyOption,
  SurveyMatrixRow,
  SurveyMatrixCol,
  SurveyLogicRule,
  SurveyLogicCondition
} from '../../types/survey';
import { AiSurveyGeneratorModal } from './AiSurveyGeneratorModal';
import { SurveyRespondentPortal } from './SurveyRespondentPortal';

interface SurveyFormBuilderProps {
  initialSurvey?: Survey | null;
  onSave: (survey: Survey, publishImmediately?: boolean) => void;
  onCancel: () => void;
  currentUser: any;
  allDocuments?: any[];
}

const QUESTION_CATEGORIES: {
  category: string;
  items: { type: SurveyQuestionType; label: string; icon: any; desc: string }[];
}[] = [
  {
    category: 'คำถามพื้นฐาน (Basic)',
    items: [
      { type: 'single_choice', label: 'ตัวเลือกเดียว (Radio)', icon: List, desc: 'เลือกได้ 1 ตัวเลือก' },
      { type: 'multiple_choice', label: 'หลายตัวเลือก (Checkbox)', icon: CheckSquare, desc: 'เลือกได้มากกว่า 1 ตัวเลือก' },
      { type: 'dropdown', label: 'รายการเลื่อน (Dropdown)', icon: ChevronDown, desc: 'เลือกจากรายการดรอปดาวน์' },
      { type: 'text_short', label: 'ข้อความสั้น (Short Text)', icon: Type, desc: 'ข้อความบรรทัดเดียว' },
      { type: 'text_long', label: 'ข้อความยาว (Paragraph)', icon: AlignLeft, desc: 'ย่อหน้าหรือข้อความหลายบรรทัด' },
    ]
  },
  {
    category: 'การวัดและประเมินผล (Rating & Scale)',
    items: [
      { type: 'rating_stars', label: 'ให้คะแนนดาว (Star Rating)', icon: Star, desc: 'ประเมิน 1-5 หรือ 1-10 ดาว' },
      { type: 'nps_score', label: 'NPS Score (0-10)', icon: Sliders, desc: 'วัดความพึงพอใจ/บอกต่อ 0-10' },
      { type: 'likert_scale', label: 'สเกลความเห็น (Likert Scale)', icon: Sliders, desc: 'เห็นด้วยอย่างยิ่ง - ไม่เห็นด้วย' },
      { type: 'slider_score', label: 'แถบเลื่อนคะแนน (Slider)', icon: Sliders, desc: 'สไลเดอร์คะแนนกำหนดเอง' },
      { type: 'matrix_rating', label: 'ตารางประเมิน (Matrix Rating)', icon: LayoutGrid, desc: 'ตารางประเมินหลายหัวข้อ' },
      { type: 'ranking', label: 'จัดลำดับ (Ranking)', icon: Hash, desc: 'ลากวางจัดลำดับความสำคัญ' },
    ]
  },
  {
    category: 'ขั้นสูงและเฉพาะทาง (Advanced & Specialized)',
    items: [
      { type: 'cascader', label: 'ลำดับชั้น (Cascader)', icon: Layers, desc: 'เช่น จังหวัด > อำเภอ > ตำบล' },
      { type: 'file_upload', label: 'แนบไฟล์/รูปถ่าย', icon: FileUp, desc: 'อัปโหลดเอกสารหรือรูปถ่าย' },
      { type: 'signature', label: 'ลายเซ็นดิจิทัล (Signature)', icon: FileEdit, desc: 'ลงนามลายมือชื่อออนไลน์' },
      { type: 'contact_info', label: 'ข้อมูลผู้ติดต่อราชการ', icon: Phone, desc: 'ชื่อ ตำแหน่ง สังกัด เบอร์โทร' },
      { type: 'rsvp_status', label: 'แบบตอบรับคำสั่ง/ประชุม (RSVP)', icon: CheckCircle2, desc: 'เข้าร่วม/มอบหมายผู้แทน' },
      { type: 'date_time', label: 'วันที่และเวลา (Date/Time)', icon: Calendar, desc: 'ปฏิทินเลือกวันที่เวลา' },
      { type: 'section_header', label: 'หัวข้อแบ่งตอน/แบ่งหน้า', icon: FileText, desc: 'คั่นตอนหรือหน้าของแบบสำรวจ' },
    ]
  }
];

export const SurveyFormBuilder: React.FC<SurveyFormBuilderProps> = ({
  initialSurvey,
  onSave,
  onCancel,
  currentUser,
  allDocuments = [],
}) => {
  // State: Survey Core
  const [title, setTitle] = useState(initialSurvey?.title || 'แบบสำรวจและประเมินผลฉบับใหม่');
  const [description, setDescription] = useState(initialSurvey?.description || 'ขอความอนุเคราะห์ตอบแบบสำรวจเพื่อนำผลไปปรับปรุงและพัฒนางานราชการต่อไป');
  const [category, setCategory] = useState(initialSurvey?.category || 'satisfaction');
  const [categoryLabel, setCategoryLabel] = useState(initialSurvey?.categoryLabel || 'ความพึงพอใจ');
  const [department, setDepartment] = useState(initialSurvey?.department || currentUser?.department || 'สำนักงาน ปภ. จังหวัดระยอง');
  const [questions, setQuestions] = useState<SurveyQuestion[]>(initialSurvey?.questions || []);
  
  // State: Settings
  const [settings, setSettings] = useState<SurveySettings>(initialSurvey?.settings || {
    status: 'published',
    themeColor: '#2563eb',
    headerLogoType: 'ddpm',
    showProgressBar: true,
    showQuestionNumbers: true,
    allowAnonymous: true,
    requireLogin: false,
    limitOneResponsePerDevice: false,
    thankYouTitle: 'ขอบพระคุณสำหรับข้อคิดเห็นอันมีค่ายิ่ง',
    thankYouMessage: 'สำนักงาน ปภ. จังหวัดระยอง ได้รับคำตอบของท่านเรียบร้อยแล้ว และจะนำผลไปพัฒนาการปฏิบัติงานต่อไป',
    showSummaryToRespondents: false,
    surveyMode: 'survey',
    isExamMode: false,
    passingScorePercent: 70,
  });

  // State: Active View & Selections
  const [activeTab, setActiveTab] = useState<'builder' | 'logic' | 'settings' | 'theme' | 'preview'>('builder');
  const [selectedQuestionId, setSelectedQuestionId] = useState<string | null>(null);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [showAiModal, setShowAiModal] = useState(false);
  const [showBatchImportModal, setShowBatchImportModal] = useState(false);
  const [batchText, setBatchText] = useState('');

  const selectedQuestion = questions.find(q => q.id === selectedQuestionId) || questions[0] || null;

  // Add Question
  const handleAddQuestion = (type: SurveyQuestionType) => {
    const newId = `q_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    let initialOptions: SurveyOption[] | undefined;
    let initialMatrixRows: SurveyMatrixRow[] | undefined;
    let initialMatrixCols: SurveyMatrixCol[] | undefined;

    if (['single_choice', 'multiple_choice', 'dropdown', 'ranking'].includes(type)) {
      initialOptions = [
        { id: `opt_${Date.now()}_1`, text: 'ตัวเลือกที่ 1' },
        { id: `opt_${Date.now()}_2`, text: 'ตัวเลือกที่ 2' },
        { id: `opt_${Date.now()}_3`, text: 'ตัวเลือกที่ 3' }
      ];
    } else if (type === 'matrix_rating') {
      initialMatrixRows = [
        { id: 'r1', text: '1. ขั้นตอนและกระบวนการมีความสะดวกรวดเร็ว' },
        { id: 'r2', text: '2. เจ้าหน้าที่ให้บริการด้วยความสุภาพและเต็มใจ' },
        { id: 'r3', text: '3. ความถูกต้องชัดเจนของข้อมูลและเอกสาร' }
      ];
      initialMatrixCols = [
        { id: 'c1', text: 'น้อยที่สุด', score: 1 },
        { id: 'c2', text: 'น้อย', score: 2 },
        { id: 'c3', text: 'ปานกลาง', score: 3 },
        { id: 'c4', text: 'มาก', score: 4 },
        { id: 'c5', text: 'มากที่สุด', score: 5 }
      ];
    } else if (type === 'likert_scale') {
      initialOptions = [
        { id: 'lk1', text: 'ไม่เห็นด้วยอย่างยิ่ง', score: 1 },
        { id: 'lk2', text: 'ไม่เห็นด้วย', score: 2 },
        { id: 'lk3', text: 'ปานกลาง/เป็นกลาง', score: 3 },
        { id: 'lk4', text: 'เห็นด้วย', score: 4 },
        { id: 'lk5', text: 'เห็นด้วยอย่างยิ่ง', score: 5 }
      ];
    }

    const newQuestion: SurveyQuestion = {
      id: newId,
      type,
      title: type === 'section_header' ? 'ส่วนที่ 1: ข้อมูลทั่วไป' : `คำถามที่ ${questions.length + 1}`,
      description: '',
      required: type !== 'section_header',
      options: initialOptions,
      matrixRows: initialMatrixRows,
      matrixCols: initialMatrixCols,
      minScore: type === 'nps_score' ? 0 : 1,
      maxScore: type === 'nps_score' ? 10 : 5,
      allowOther: false,
    };

    setQuestions([...questions, newQuestion]);
    setSelectedQuestionId(newId);
  };

  // Update Question
  const handleUpdateQuestion = (id: string, updates: Partial<SurveyQuestion>) => {
    setQuestions(questions.map(q => q.id === id ? { ...q, ...updates } : q));
  };

  // Delete Question
  const handleDeleteQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
    if (selectedQuestionId === id) {
      setSelectedQuestionId(null);
    }
  };

  // Duplicate Question
  const handleDuplicateQuestion = (q: SurveyQuestion) => {
    const newId = `q_${Date.now()}_${Math.random().toString(36).substring(7)}`;
    const clonedQuestion: SurveyQuestion = {
      ...q,
      id: newId,
      title: `${q.title} (สำเนา)`,
      options: q.options?.map(o => ({ ...o, id: `opt_${Date.now()}_${Math.random().toString(36).substring(7)}` }))
    };
    const index = questions.findIndex(item => item.id === q.id);
    const newQuestions = [...questions];
    newQuestions.splice(index + 1, 0, clonedQuestion);
    setQuestions(newQuestions);
    setSelectedQuestionId(newId);
  };

  // Move Question
  const handleMoveQuestion = (index: number, direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= questions.length) return;
    const newQuestions = [...questions];
    const temp = newQuestions[index];
    newQuestions[index] = newQuestions[newIndex];
    newQuestions[newIndex] = temp;
    setQuestions(newQuestions);
  };

  // Batch Text Importer (SurveyKing Style)
  const handleParseBatchText = () => {
    if (!batchText.trim()) return;

    const lines = batchText.split('\n').map(l => l.trim()).filter(Boolean);
    const parsedQuestions: SurveyQuestion[] = [];
    let currentQ: Partial<SurveyQuestion> | null = null;
    let currentOpts: SurveyOption[] = [];

    lines.forEach((line, idx) => {
      // Check if line starts with number e.g. "1.", "1)", "ข้อ 1"
      const isQuestionHeader = /^(\d+[\.\)]|ข้อ\s*\d+)/i.test(line);

      if (isQuestionHeader) {
        if (currentQ) {
          parsedQuestions.push({
            id: `q_batch_${Date.now()}_${parsedQuestions.length}`,
            type: currentOpts.length > 0 ? 'single_choice' : 'text_short',
            title: currentQ.title || 'คำถาม',
            required: true,
            options: currentOpts.length > 0 ? currentOpts : undefined
          });
          currentOpts = [];
        }
        currentQ = { title: line.replace(/^(\d+[\.\)]|ข้อ\s*\d+)\s*/i, '').trim() };
      } else if (/^[a-zA-Zก-ฮ]\.|\d+\.|\-\s/i.test(line) || currentQ) {
        const optText = line.replace(/^[a-zA-Zก-ฮ]\.|\d+\.|\-\s/i, '').trim();
        currentOpts.push({
          id: `opt_batch_${Date.now()}_${currentOpts.length + 1}`,
          text: optText
        });
      }
    });

    if (currentQ) {
      parsedQuestions.push({
        id: `q_batch_${Date.now()}_${parsedQuestions.length}`,
        type: currentOpts.length > 0 ? 'single_choice' : 'text_short',
        title: (currentQ as any).title || 'คำถาม',
        required: true,
        options: currentOpts.length > 0 ? currentOpts : undefined
      });
    }

    if (parsedQuestions.length > 0) {
      setQuestions([...questions, ...parsedQuestions]);
      setShowBatchImportModal(false);
      setBatchText('');
    }
  };

  // Save Survey
  const handleSave = (publishImmediately: boolean = false) => {
    if (!title.trim()) {
      alert('กรุณาระบุชื่อแบบสำรวจ');
      return;
    }

    const surveyToSave: Survey = {
      id: initialSurvey?.id || `survey_${Date.now()}`,
      title,
      description,
      category: category as any,
      categoryLabel,
      department,
      creatorId: currentUser?.username || 'admin',
      creatorName: currentUser?.fullname || 'ผู้ดูแลระบบ ปภ.',
      createdAt: initialSurvey?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      viewCount: initialSurvey?.viewCount || 0,
      responseCount: initialSurvey?.responseCount || 0,
      questions,
      settings: {
        ...settings,
        status: publishImmediately ? 'published' : settings.status
      }
    };

    onSave(surveyToSave, publishImmediately);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-100 dark:bg-slate-950 flex flex-col overflow-hidden animate-fade-in">
      
      {/* 1. TOP HEADER BAR */}
      <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-6 flex items-center justify-between shadow-xs z-30">
        <div className="flex items-center gap-4">
          <button 
            type="button"
            onClick={onCancel}
            className="p-2 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition"
            title="ย้อนกลับ"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="text-base font-bold text-slate-900 dark:text-slate-100 bg-transparent border-none p-0 focus:outline-none focus:ring-0 w-80 md:w-96"
                placeholder="ชื่อแบบสำรวจ..."
              />
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                settings.status === 'published' 
                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400' 
                  : 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
              }`}>
                {settings.status === 'published' ? 'เผยแพร่' : 'ฉบับร่าง'}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <span>{questions.length} คำถาม</span>
              <span>•</span>
              <span>{department}</span>
            </div>
          </div>
        </div>

        {/* Center Tabs */}
        <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl gap-1">
          {[
            { id: 'builder', label: '1. ออกแบบฟอร์ม', icon: LayoutGrid },
            { id: 'logic', label: '2. ตรรกะเงื่อนไข (Logic)', icon: GitBranch },
            { id: 'settings', label: '3. ตั้งค่าระบบ', icon: Settings },
            { id: 'theme', label: '4. ธีมและตราสัญลักษณ์', icon: Palette },
            { id: 'preview', label: '5. พรีวิวสด', icon: Eye },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                  isActive
                    ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden md:inline">{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowAiModal(true)}
            className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 dark:bg-purple-950/50 dark:hover:bg-purple-900/50 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">AI Generator</span>
          </button>
          <button
            type="button"
            onClick={() => handleSave(false)}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-xl text-xs font-bold transition"
          >
            บันทึกร่าง
          </button>
          <button
            type="button"
            onClick={() => handleSave(true)}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-lg shadow-blue-500/25 active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>เผยแพร่</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN 3-COLUMN STUDIO WORKSPACE */}
      {activeTab === 'builder' && (
        <div className="flex-1 flex overflow-hidden">
          
          {/* LEFT COLUMN: Question Palette & Outline Tree */}
          <aside className="w-72 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col shrink-0 overflow-y-auto">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/40">
              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                คลังประเภทคำถาม
              </span>
              <button
                type="button"
                onClick={() => setShowBatchImportModal(true)}
                className="text-[11px] text-blue-600 dark:text-blue-400 font-bold hover:underline"
              >
                + นำเข้าข้อความชุด
              </button>
            </div>

            <div className="p-3 space-y-5 flex-1">
              {QUESTION_CATEGORIES.map((cat, catIdx) => (
                <div key={catIdx} className="space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-400 dark:text-slate-500 px-2 uppercase tracking-wide">
                    {cat.category}
                  </div>
                  <div className="grid grid-cols-1 gap-1">
                    {cat.items.map((item) => {
                      const Icon = item.icon;
                      return (
                        <button
                          key={item.type}
                          type="button"
                          onClick={() => handleAddQuestion(item.type)}
                          className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-blue-50 dark:hover:bg-blue-950/40 border border-transparent hover:border-blue-200 dark:hover:border-blue-800 text-left transition group"
                        >
                          <div className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 group-hover:bg-blue-600 group-hover:text-white flex items-center justify-center transition shadow-xs">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-xs font-bold text-slate-700 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400 line-clamp-1">
                              {item.label}
                            </div>
                            <div className="text-[10px] text-slate-400 line-clamp-1">
                              {item.desc}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Outline Question Navigator Tree */}
            <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
              <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-2 flex items-center justify-between">
                <span>แผนผังคำถาม ({questions.length})</span>
              </div>
              <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                {questions.map((q, idx) => (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => setSelectedQuestionId(q.id)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center justify-between transition ${
                      selectedQuestionId === q.id 
                        ? 'bg-blue-600 text-white font-bold' 
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
                    }`}
                  >
                    <span className="truncate">
                      {idx + 1}. {q.title || 'ไม่มีชื่อ'}
                    </span>
                    {q.required && (
                      <span className={`text-[10px] ${selectedQuestionId === q.id ? 'text-white' : 'text-rose-500'}`}>*</span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* CENTER COLUMN: Interactive Live Form Canvas */}
          <main className="flex-1 bg-slate-100 dark:bg-slate-950 p-6 overflow-y-auto">
            <div className="max-w-3xl mx-auto space-y-4 pb-28">
              
              {/* Survey Header Card */}
              <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="ชื่อแบบสำรวจ..."
                  className="w-full text-xl font-extrabold text-slate-900 dark:text-slate-100 bg-transparent border-none p-0 focus:outline-none focus:ring-0 placeholder:text-slate-300"
                />
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="คำอธิบายหรือคำชี้แจงสำหรับผู้ตอบแบบสำรวจ..."
                  className="w-full text-xs text-slate-600 dark:text-slate-300 bg-transparent border-none p-0 focus:outline-none focus:ring-0 resize-none leading-relaxed placeholder:text-slate-400"
                />
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-3 text-xs">
                  <span className="text-slate-400 font-bold">หมวดหมู่:</span>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="p-1.5 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs font-bold text-blue-600 dark:text-blue-400 border border-slate-200 dark:border-slate-700 focus:outline-none"
                  >
                    <option value="satisfaction">ความพึงพอใจการบริการ (ก.พ.ร.)</option>
                    <option value="disaster_readiness">ความพร้อมรับมือภัยพิบัติ</option>
                    <option value="training">การฝึกซ้อมและอบรม อปพร.</option>
                    <option value="exam_quiz">แบบทดสอบ/วัดความรู้ (Quiz)</option>
                    <option value="rsvp_acknowledgment">แบบตอบรับดิจิทัล (RSVP)</option>
                    <option value="assessment">การประเมินผลองค์กร</option>
                    <option value="general">แบบสำรวจทั่วไป</option>
                  </select>
                </div>
              </div>

              {/* Questions List */}
              {questions.length === 0 ? (
                <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border border-dashed border-slate-300 dark:border-slate-800 p-8 space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto">
                    <Plus className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    ยังไม่มีคำถามในแบบสำรวจนี้
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    เลือกประเภทคำถามจากแถบเครื่องมือทางซ้าย หรือใช้ AI Generator เพื่อสร้างคำถามอัตโนมัติ
                  </p>
                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={() => handleAddQuestion('single_choice')}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition"
                    >
                      + เพิ่มคำถามแรก
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowAiModal(true)}
                      className="px-4 py-2 bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 border border-purple-200 dark:border-purple-800 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>ให้ AI ช่วยสร้าง</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {questions.map((q, qIdx) => {
                    const isSelected = selectedQuestionId === q.id;
                    return (
                      <div
                        key={q.id}
                        onClick={() => setSelectedQuestionId(q.id)}
                        className={`bg-white dark:bg-slate-900 rounded-3xl p-6 border transition shadow-xs cursor-pointer ${
                          isSelected
                            ? 'border-blue-500 ring-2 ring-blue-500/20 shadow-md'
                            : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                        }`}
                      >
                        {/* Question Top Controls */}
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs font-bold flex items-center justify-center">
                              {qIdx + 1}
                            </span>
                            <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400">
                              {q.type}
                            </span>
                            {q.required && (
                              <span className="text-xs font-bold text-rose-500">*จำเป็น</span>
                            )}
                          </div>

                          <div className="flex items-center gap-1">
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleMoveQuestion(qIdx, 'up'); }}
                              disabled={qIdx === 0}
                              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 rounded-lg"
                              title="ย้ายขึ้น"
                            >
                              <ChevronUp className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleMoveQuestion(qIdx, 'down'); }}
                              disabled={qIdx === questions.length - 1}
                              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 disabled:opacity-30 rounded-lg"
                              title="ย้ายลง"
                            >
                              <ChevronDown className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleDuplicateQuestion(q); }}
                              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
                              title="ทำสำเนา"
                            >
                              <Copy className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleDeleteQuestion(q.id); }}
                              className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                              title="ลบคำถาม"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                        {/* In-place Title & Description */}
                        <div className="space-y-2 mb-4">
                          <input
                            type="text"
                            value={q.title}
                            onChange={(e) => handleUpdateQuestion(q.id, { title: e.target.value })}
                            placeholder="ระบุคำถาม..."
                            className="w-full text-sm font-bold text-slate-800 dark:text-slate-100 bg-transparent border-none p-0 focus:outline-none focus:ring-0"
                          />
                          <input
                            type="text"
                            value={q.description || ''}
                            onChange={(e) => handleUpdateQuestion(q.id, { description: e.target.value })}
                            placeholder="คำอธิบายเพิ่มเติม (ถ้ามี)..."
                            className="w-full text-xs text-slate-500 bg-transparent border-none p-0 focus:outline-none focus:ring-0"
                          />
                        </div>

                        {/* Interactive Option Renderers */}
                        {['single_choice', 'multiple_choice', 'dropdown', 'ranking'].includes(q.type) && (
                          <div className="space-y-2">
                            {q.options?.map((opt, optIdx) => (
                              <div key={opt.id} className="flex items-center gap-2">
                                <div className={`w-4 h-4 rounded-full border-2 border-slate-300 dark:border-slate-600 ${q.type === 'multiple_choice' ? 'rounded-md' : 'rounded-full'}`} />
                                <input
                                  type="text"
                                  value={opt.text}
                                  onChange={(e) => {
                                    const newOpts = [...(q.options || [])];
                                    newOpts[optIdx] = { ...opt, text: e.target.value };
                                    handleUpdateQuestion(q.id, { options: newOpts });
                                  }}
                                  className="flex-1 p-1.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                                />
                                {settings.isExamMode && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newOpts = q.options?.map(o => ({
                                        ...o,
                                        isCorrect: o.id === opt.id ? !o.isCorrect : (q.type === 'single_choice' ? false : o.isCorrect)
                                      }));
                                      handleUpdateQuestion(q.id, { options: newOpts });
                                    }}
                                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition ${
                                      opt.isCorrect
                                        ? 'bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-950 dark:text-emerald-400'
                                        : 'bg-slate-100 text-slate-500 border-slate-200 hover:bg-slate-200'
                                    }`}
                                  >
                                    {opt.isCorrect ? '✓ คำตอบถูก' : 'ตั้งเป็นเฉลย'}
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => {
                                    const newOpts = q.options?.filter(o => o.id !== opt.id);
                                    handleUpdateQuestion(q.id, { options: newOpts });
                                  }}
                                  className="p-1 text-slate-300 hover:text-rose-500"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                            <button
                              type="button"
                              onClick={() => {
                                const newOpts = [...(q.options || []), { id: `opt_${Date.now()}`, text: `ตัวเลือกที่ ${(q.options?.length || 0) + 1}` }];
                                handleUpdateQuestion(q.id, { options: newOpts });
                              }}
                              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 mt-2"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>เพิ่มตัวเลือก</span>
                            </button>
                          </div>
                        )}

                        {q.type === 'rating_stars' && (
                          <div className="flex items-center gap-2 py-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star key={star} className="w-6 h-6 text-amber-400 fill-amber-400" />
                            ))}
                            <span className="text-xs text-slate-400 ml-2">(1-5 ดาว)</span>
                          </div>
                        )}

                        {q.type === 'nps_score' && (
                          <div className="flex flex-wrap gap-1.5 py-2">
                            {Array.from({ length: 11 }).map((_, nps) => (
                              <span key={nps} className="w-7 h-7 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold flex items-center justify-center">
                                {nps}
                              </span>
                            ))}
                          </div>
                        )}

                        {q.type === 'matrix_rating' && (
                          <div className="overflow-x-auto py-2">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="border-b border-slate-100 dark:border-slate-800">
                                  <th className="text-left py-2 font-bold text-slate-500">หัวข้อประเมิน</th>
                                  {q.matrixCols?.map(c => (
                                    <th key={c.id} className="text-center py-2 px-2 text-slate-400">{c.text}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {q.matrixRows?.map(r => (
                                  <tr key={r.id} className="border-b border-slate-50 dark:border-slate-800/50">
                                    <td className="py-2 text-slate-700 dark:text-slate-300 font-medium">{r.text}</td>
                                    {q.matrixCols?.map(c => (
                                      <td key={c.id} className="text-center py-2">
                                        <div className="w-3.5 h-3.5 rounded-full border border-slate-300 dark:border-slate-600 mx-auto" />
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        )}

                        {q.type === 'signature' && (
                          <div className="p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 text-center text-xs text-slate-400">
                            <FileEdit className="w-6 h-6 mx-auto mb-1 text-slate-400" />
                            <span>พื้นที่ลงลายมือชื่อดิจิทัล (Digital Signature Pad)</span>
                          </div>
                        )}

                        {q.type === 'contact_info' && (
                          <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl">
                            <div>ชื่อ-นามสกุล [ช่องกรอก]</div>
                            <div>ตำแหน่ง [ช่องกรอก]</div>
                            <div>สังกัด/หน่วยงาน [ช่องกรอก]</div>
                            <div>เบอร์โทรศัพท์ [ช่องกรอก]</div>
                          </div>
                        )}

                      </div>
                    );
                  })}
                </div>
              )}

            </div>
          </main>

          {/* RIGHT COLUMN: Property Inspector & Logic Settings */}
          {selectedQuestion && (
            <aside className="w-80 bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 flex flex-col shrink-0 overflow-y-auto">
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
                  คุณสมบัติข้อคำถาม (Inspector)
                </span>
              </div>

              <div className="p-4 space-y-4 text-xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    ประเภทคำถาม
                  </label>
                  <select
                    value={selectedQuestion.type}
                    onChange={(e) => handleUpdateQuestion(selectedQuestion.id, { type: e.target.value as any })}
                    className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 focus:outline-none"
                  >
                    <option value="single_choice">ตัวเลือกเดียว (Radio)</option>
                    <option value="multiple_choice">หลายตัวเลือก (Checkbox)</option>
                    <option value="dropdown">รายการเลื่อน (Dropdown)</option>
                    <option value="text_short">ข้อความสั้น (Short Text)</option>
                    <option value="text_long">ข้อความยาว (Paragraph)</option>
                    <option value="rating_stars">ให้คะแนนดาว (Star Rating)</option>
                    <option value="nps_score">NPS Score (0-10)</option>
                    <option value="likert_scale">สเกลวัดความเห็น (Likert)</option>
                    <option value="matrix_rating">ตารางประเมิน (Matrix Rating)</option>
                    <option value="ranking">จัดลำดับ (Ranking)</option>
                    <option value="signature">ลายเซ็นดิจิทัล</option>
                    <option value="contact_info">ข้อมูลผู้ติดต่อราชการ</option>
                    <option value="rsvp_status">แบบตอบรับคำสั่ง (RSVP)</option>
                  </select>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <label className="flex items-center justify-between cursor-pointer">
                    <span className="font-bold text-slate-700 dark:text-slate-300">จำเป็นต้องตอบ (Required)</span>
                    <input
                      type="checkbox"
                      checked={selectedQuestion.required}
                      onChange={(e) => handleUpdateQuestion(selectedQuestion.id, { required: e.target.checked })}
                      className="w-4 h-4 rounded text-blue-600"
                    />
                  </label>

                  {['single_choice', 'multiple_choice'].includes(selectedQuestion.type) && (
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="font-bold text-slate-700 dark:text-slate-300">อนุญาตระบุ "อื่นๆ" (Other text)</span>
                      <input
                        type="checkbox"
                        checked={selectedQuestion.allowOther || false}
                        onChange={(e) => handleUpdateQuestion(selectedQuestion.id, { allowOther: e.target.checked })}
                        className="w-4 h-4 rounded text-blue-600"
                      />
                    </label>
                  )}

                  {settings.isExamMode && (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                        คะแนนประจำข้อนี้ (Score Points)
                      </label>
                      <input
                        type="number"
                        value={selectedQuestion.scorePoints || 0}
                        onChange={(e) => handleUpdateQuestion(selectedQuestion.id, { scorePoints: Number(e.target.value) })}
                        className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                      />
                    </div>
                  )}
                </div>
              </div>
            </aside>
          )}

        </div>
      )}

      {/* 3. SETTINGS TAB */}
      {activeTab === 'settings' && (
        <div className="flex-1 bg-slate-50 dark:bg-slate-950 p-8 overflow-y-auto">
          <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Settings className="w-5 h-5 text-blue-600" />
              <span>การตั้งค่าความปลอดภัยและการเข้าถึง (SurveyKing Enterprise)</span>
            </h3>

            <div className="space-y-4 text-xs">
              <label className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 cursor-pointer">
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">ตอบแบบนิรนาม (Allow Anonymous)</div>
                  <div className="text-[11px] text-slate-500">ผู้ตอบไม่จำเป็นต้องระบุชื่อหรือตำแหน่ง</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.allowAnonymous}
                  onChange={(e) => setSettings({ ...settings, allowAnonymous: e.target.checked })}
                  className="w-5 h-5 rounded text-blue-600"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 cursor-pointer">
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">จำกัด 1 คำตอบต่อ 1 อุปกรณ์ (Limit One per Device)</div>
                  <div className="text-[11px] text-slate-500">ป้องกันการส่งคำตอบซ้ำจากเครื่องเดิม</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.limitOneResponsePerDevice}
                  onChange={(e) => setSettings({ ...settings, limitOneResponsePerDevice: e.target.checked })}
                  className="w-5 h-5 rounded text-blue-600"
                />
              </label>

              <label className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 cursor-pointer">
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">โหมดแบบทดสอบวัดผล (Quiz / Exam Mode)</div>
                  <div className="text-[11px] text-slate-500">มีคะแนน เกณฑ์ผ่าน และออกใบประกาศนียบัตร</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.isExamMode}
                  onChange={(e) => setSettings({ ...settings, isExamMode: e.target.checked })}
                  className="w-5 h-5 rounded text-blue-600"
                />
              </label>

              {settings.isExamMode && (
                <div className="p-4 bg-purple-50 dark:bg-purple-950/30 rounded-2xl border border-purple-200 dark:border-purple-900/50 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="font-bold text-purple-900 dark:text-purple-200 flex items-center gap-1.5">
                      <Award className="w-4 h-4 text-purple-600" />
                      <span>ตั้งค่าระบบแบบทดสอบวัดผล (Quiz Settings)</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-600 dark:text-slate-300">เกณฑ์คะแนนผ่าน (%):</span>
                    <input
                      type="number"
                      value={settings.passingScorePercent || 70}
                      onChange={(e) => setSettings({ ...settings, passingScorePercent: Number(e.target.value) })}
                      className="w-20 p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-center font-bold"
                    />
                  </div>

                  <div className="pt-3 border-t border-purple-200/60 dark:border-purple-900/40 space-y-3">
                    <label className="flex items-center justify-between cursor-pointer">
                      <span className="font-bold text-slate-800 dark:text-slate-200">
                        เปิดใช้งานการออกใบประกาศนียบัตร e-Certificate เมื่อสอบผ่าน
                      </span>
                      <input
                        type="checkbox"
                        checked={settings.enableCertificate ?? true}
                        onChange={(e) => setSettings({ ...settings, enableCertificate: e.target.checked })}
                        className="w-4 h-4 rounded text-purple-600"
                      />
                    </label>

                    {(settings.enableCertificate ?? true) && (
                      <div className="space-y-3 pt-2">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                            หัวเรื่องใบประกาศนียบัตร:
                          </label>
                          <input
                            type="text"
                            value={settings.certificateTitle || 'ใบประกาศนียบัตรรับรองผลการประเมินความรู้'}
                            onChange={(e) => setSettings({ ...settings, certificateTitle: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                            ชื่อหลักสูตรที่ระบุบนใบประกาศฯ:
                          </label>
                          <input
                            type="text"
                            value={settings.certificateCourseName || title}
                            onChange={(e) => setSettings({ ...settings, certificateCourseName: e.target.value })}
                            placeholder="ระบุชื่อหลักสูตร หรือจะใช้ชื่อแบบสำรวจโดยอัตโนมัติ"
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                              ชื่อหน่วยงานผู้ออกใบประกาศฯ:
                            </label>
                            <input
                              type="text"
                              value={settings.certificateOrgName || 'สำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง'}
                              onChange={(e) => setSettings({ ...settings, certificateOrgName: e.target.value })}
                              className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                              ชื่อผู้ลงนาม (ประธาน/หัวหน้าหน่วยงาน):
                            </label>
                            <input
                              type="text"
                              value={settings.certificateSignerName || 'นายประเสริฐ จิตต์ภักดี'}
                              onChange={(e) => setSettings({ ...settings, certificateSignerName: e.target.value })}
                              className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                            ตำแหน่งผู้ลงนาม:
                          </label>
                          <input
                            type="text"
                            value={settings.certificateSignerPosition || 'หัวหน้าสำนักงานป้องกันและบรรเทาสาธารณภัยจังหวัดระยอง'}
                            onChange={(e) => setSettings({ ...settings, certificateSignerPosition: e.target.value })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                            ธีมสีขอบใบประกาศนียบัตร:
                          </label>
                          <select
                            value={settings.certificateTheme || 'classic_gold'}
                            onChange={(e) => setSettings({ ...settings, certificateTheme: e.target.value as any })}
                            className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs"
                          >
                            <option value="classic_gold">สีทองอร่าม มาตรฐานราชการ (Classic Gold)</option>
                            <option value="royal_navy">สีน้ำเงินกรมท่า หรูหรา (Royal Navy)</option>
                            <option value="modern_emerald">สีเขียวมรกต สิ่งแวดล้อม/กู้ชีพ (Emerald)</option>
                            <option value="crimson_gov">สีแดงเลือดหมู ปภ. ระงับอัคคีภัย (Crimson Gov)</option>
                            <option value="silver_slate">สีเงินเกียรติยศ เรียบหรู (Silver Slate)</option>
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  ข้อความขอบคุณหลังส่งคำตอบ (Thank You Message)
                </label>
                <textarea
                  rows={3}
                  value={settings.thankYouMessage}
                  onChange={(e) => setSettings({ ...settings, thankYouMessage: e.target.value })}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. THEME TAB */}
      {activeTab === 'theme' && (
        <div className="flex-1 bg-slate-50 dark:bg-slate-950 p-8 overflow-y-auto">
          <div className="max-w-2xl mx-auto bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Palette className="w-5 h-5 text-blue-600" />
              <span>ธีมสีและตราสัญลักษณ์หน่วยงาน</span>
            </h3>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-2">
                  ตราสัญลักษณ์ส่วนหัว (Header Logo)
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { id: 'ddpm', label: 'ตรา ปภ.' },
                    { id: 'garuda', label: 'ตราครุฑราชการ' },
                    { id: 'rayong', label: 'ตราจังหวัดระยอง' },
                    { id: 'none', label: 'ไม่แสดงตรา' }
                  ].map(logo => (
                    <button
                      key={logo.id}
                      type="button"
                      onClick={() => setSettings({ ...settings, headerLogoType: logo.id as any })}
                      className={`p-3 rounded-2xl text-center font-bold border transition ${
                        settings.headerLogoType === logo.id
                          ? 'bg-blue-50 border-blue-500 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      {logo.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-2">
                  โทนสีหลักของแบบสำรวจ (Primary Theme Color)
                </label>
                <div className="flex flex-wrap gap-3">
                  {[
                    { color: '#2563eb', label: 'น้ำเงิน ปภ.' },
                    { color: '#ea580c', label: 'ส้มเตือนภัย' },
                    { color: '#7c3aed', label: 'ม่วงราชการ' },
                    { color: '#059669', label: 'เขียวสิ่งแวดล้อม' },
                    { color: '#e11d48', label: 'แดงเหตุด่วน' },
                    { color: '#0f172a', label: 'ดำหรูหรา' },
                  ].map(c => (
                    <button
                      key={c.color}
                      type="button"
                      onClick={() => setSettings({ ...settings, themeColor: c.color })}
                      className={`flex items-center gap-2 px-3 py-2 rounded-xl border transition ${
                        settings.themeColor === c.color ? 'border-slate-900 dark:border-white ring-2 ring-blue-500/20' : 'border-slate-200 dark:border-slate-700'
                      }`}
                    >
                      <span className="w-4 h-4 rounded-full" style={{ backgroundColor: c.color }} />
                      <span className="font-bold">{c.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. LIVE PREVIEW TAB */}
      {activeTab === 'preview' && (
        <div className="flex-1 bg-slate-200 dark:bg-slate-950 p-6 flex flex-col items-center overflow-y-auto">
          {/* Device Switcher */}
          <div className="flex items-center bg-white dark:bg-slate-800 p-1.5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 gap-1 mb-4">
            <button
              type="button"
              onClick={() => setPreviewDevice('desktop')}
              className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === 'desktop' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Monitor className="w-4 h-4" />
              <span>คอมพิวเตอร์</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewDevice('tablet')}
              className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === 'tablet' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Tablet className="w-4 h-4" />
              <span>แท็บเล็ต</span>
            </button>
            <button
              type="button"
              onClick={() => setPreviewDevice('mobile')}
              className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                previewDevice === 'mobile' ? 'bg-blue-600 text-white' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Smartphone className="w-4 h-4" />
              <span>มือถือ</span>
            </button>
          </div>

          {/* Device Mockup Frame */}
          <div className={`transition-all duration-300 w-full ${
            previewDevice === 'mobile' ? 'max-w-sm' : previewDevice === 'tablet' ? 'max-w-xl' : 'max-w-4xl'
          }`}>
            <SurveyRespondentPortal
              survey={{
                id: initialSurvey?.id || 'preview_survey',
                title,
                description,
                category: category as any,
                categoryLabel,
                department,
                creatorId: 'preview',
                creatorName: 'พรีวิว',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                viewCount: initialSurvey?.viewCount || 0,
                responseCount: initialSurvey?.responseCount || 0,
                questions,
                settings
              }}
              isPreviewMode={true}
              onSubmitSuccess={() => {}}
            />
          </div>
        </div>
      )}

      {/* AI GENERATOR MODAL */}
      {showAiModal && (
        <AiSurveyGeneratorModal
          onClose={() => setShowAiModal(false)}
          onGenerate={(generatedData) => {
            if (generatedData.title) setTitle(generatedData.title);
            if (generatedData.description) setDescription(generatedData.description);
            if (generatedData.category) setCategory(generatedData.category);
            if (generatedData.questions && generatedData.questions.length > 0) {
              setQuestions([...questions, ...generatedData.questions]);
            }
          }}
        />
      )}

      {/* BATCH IMPORT MODAL */}
      {showBatchImportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                นำเข้าข้อคำถามแบบชุด (Batch Text Parser)
              </h3>
              <button onClick={() => setShowBatchImportModal(false)} className="p-1 text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-slate-500">
              วางข้อความคำถามและตัวเลือก ระบบจะแปลงเป็นข้อคำถามอัตโนมัติ (เช่น 1. คำถาม ตามด้วย ก. ข. ค. ง. หรือ 1. 2. 3.)
            </p>
            <textarea
              rows={8}
              value={batchText}
              onChange={(e) => setBatchText(e.target.value)}
              placeholder="1. ท่านมีความพึงพอใจต่อบริการในภาพรวมระดับใด
ก. มากที่สุด
ข. มาก
ค. ปานกลาง
ง. น้อย

2. สิ่งที่ต้องการให้ ปภ. ระยอง ปรับปรุงเพิ่มเติม"
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-2xl text-xs font-mono border border-slate-200 dark:border-slate-700 focus:outline-none"
            />
            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowBatchImportModal(false)}
                className="px-4 py-2 text-xs text-slate-500 font-bold"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={handleParseBatchText}
                className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold"
              >
                แปลงและนำเข้าคำถาม
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default SurveyFormBuilder;
