import React, { useState, useEffect, useRef } from 'react';
import { 
  CheckCircle2, Send, Clock, AlertCircle, 
  ChevronRight, ChevronLeft, Star, Trash2, GripVertical, FileUp
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Survey, SurveyQuestion, SurveyResponse } from '../../../types/survey';

interface SurveyPublicViewerProps {
  surveyId: string;
}

const SurveyPublicViewer: React.FC<SurveyPublicViewerProps> = ({ surveyId }) => {
  const [survey, setSurvey] = useState<Survey | null>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [startTime] = useState(Date.now());
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Respondent Info (Optional based on settings)
  const [respondentInfo, setRespondentInfo] = useState({
    name: '',
    department: '',
    position: '',
    email: '',
    phone: ''
  });

  useEffect(() => {
    fetchSurvey();
  }, [surveyId]);

  const fetchSurvey = async () => {
    try {
      const res = await fetch(`/api/surveys/${surveyId}`);
      if (!res.ok) throw new Error('Survey not found');
      const data = await res.json();
      setSurvey(data);
      
      // Increment view count
      fetch(`/api/surveys/${surveyId}/view`, { method: 'POST' });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (qId: string, value: any) => {
    setAnswers(prev => ({ ...prev, [qId]: value }));
  };

  const calculateTotalScore = () => {
    if (!survey) return 0;
    let total = 0;
    let countable = 0;

    survey.questions.forEach(q => {
      const ans = answers[q.id];
      if (q.type === 'rating' || q.type === 'scale') {
        total += Number(ans || 0);
        countable++;
      } else if (q.type === 'matrix') {
        const matrixAns = ans as Record<string, any> || {};
        const rows = Object.values(matrixAns);
        rows.forEach(r => {
          total += Number(r || 0);
          countable++;
        });
      }
    });

    return countable > 0 ? total / countable : 0;
  };

  const handleSubmit = async () => {
    if (!survey) return;

    // Basic validation
    const missingRequired = survey.questions.find(q => q.required && !answers[q.id]);
    if (missingRequired) {
      alert(`กรุณาตอบคำถาม: ${missingRequired.title}`);
      return;
    }

    setIsSubmitting(true);
    const timeSpentSeconds = Math.round((Date.now() - startTime) / 1000);
    const totalScore = calculateTotalScore();

    const response: Partial<SurveyResponse> = {
      surveyId: survey.id,
      surveyTitle: survey.title,
      respondentName: respondentInfo.name,
      respondentDepartment: respondentInfo.department,
      respondentPosition: respondentInfo.position,
      respondentEmail: respondentInfo.email,
      respondentPhone: respondentInfo.phone,
      timeSpentSeconds,
      totalScore,
      answers,
      deviceInfo: navigator.userAgent,
      respondentIp: 'Client-side'
    };

    try {
      const res = await fetch(`/api/surveys/${survey.id}/responses`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(response)
      });
      if (res.ok) setSubmitted(true);
    } catch (err) {
      console.error('Submission failed:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="text-center space-y-4">
        <div className="w-16 h-16 border-4 border-indigo-600/20 border-t-indigo-600 rounded-full animate-spin mx-auto"></div>
        <p className="text-slate-500 font-bold tracking-widest uppercase text-sm">กำลังเตรียมแบบสำรวจ...</p>
      </div>
    </div>
  );

  if (error || !survey) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white p-10 rounded-3xl shadow-xl border border-slate-200 text-center space-y-6">
        <div className="w-20 h-20 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto">
          <AlertCircle className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-black text-slate-900">ไม่พบแบบสำรวจนี้</h2>
        <p className="text-slate-500 font-medium">ลิงก์อาจจะไม่ถูกต้อง หรือแบบสำรวจถูกปิดใช้งานไปแล้ว</p>
        <button onClick={() => window.location.reload()} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all">ลองใหม่อีกครั้ง</button>
      </div>
    </div>
  );

  if (submitted) return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white p-10 rounded-3xl shadow-2xl border border-slate-200 text-center space-y-8"
      >
        <div className="w-24 h-24 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-100 animate-bounce">
          <CheckCircle2 className="w-12 h-12" />
        </div>
        <div className="space-y-3">
          <h2 className="text-3xl font-black text-slate-900 leading-tight">ส่งข้อมูลเรียบร้อยแล้ว</h2>
          <p className="text-slate-600 text-lg font-medium leading-relaxed">
            {survey.settings.thankYouMessage || 'ขอบพระคุณสำหรับการสละเวลาตอบแบบสำรวจ ข้อมูลของท่านเป็นประโยชน์อย่างยิ่งในการพัฒนาองค์กร'}
          </p>
        </div>
        <div className="pt-6 border-t border-slate-100 flex flex-col items-center gap-2">
          <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Powered by SurveyKing Enterprise</p>
          <div className="h-1 w-20 bg-indigo-600 rounded-full" />
        </div>
      </motion.div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 py-10 px-4 md:px-8">
      <div className="max-w-3xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="h-3 bg-indigo-600" />
          <div className="p-8 md:p-12 space-y-4">
            <h1 className="text-3xl font-black text-slate-900 tracking-tight leading-tight">{survey.title}</h1>
            <p className="text-slate-500 text-lg leading-relaxed">{survey.description}</p>
            <div className="pt-6 flex flex-wrap gap-4 items-center border-t border-slate-50">
              <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold uppercase tracking-widest">{survey.categoryLabel}</span>
              <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">• {survey.department}</span>
              <div className="flex-1" />
              {survey.settings.showProgressBar && (
                <div className="flex items-center gap-3">
                  <div className="w-32 h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-indigo-600 transition-all duration-500" 
                      style={{ width: `${((currentStep + 1) / (survey.questions.length + 1)) * 100}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-black text-indigo-600 uppercase tracking-tighter">Progress</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Form Body */}
        <div className="space-y-6 pb-20">
          {survey.questions.map((q, idx) => (
            <motion.div 
              key={q.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="bg-white p-8 md:p-10 rounded-3xl shadow-sm border border-slate-200 space-y-8 group transition-all hover:shadow-md"
            >
              <div className="space-y-2">
                <div className="flex items-start gap-4">
                  {survey.settings.showQuestionNumbers && (
                    <span className="text-2xl font-black text-indigo-600 pt-1 leading-none">{idx + 1}.</span>
                  )}
                  <h3 className="text-2xl font-bold text-slate-900 leading-tight">
                    {q.title}
                    {q.required && <span className="text-rose-500 ml-2 animate-pulse">*</span>}
                  </h3>
                </div>
                {q.description && <p className="ml-0 md:ml-10 text-slate-500 font-medium">{q.description}</p>}
              </div>

              <div className="ml-0 md:ml-10 space-y-4">
                {['text', 'textarea'].includes(q.type) && (
                  q.type === 'textarea' ? (
                    <textarea 
                      className="w-full bg-slate-50/50 border-2 border-slate-100 rounded-2xl p-6 focus:bg-white focus:border-indigo-600 focus:ring-0 transition-all text-lg placeholder:text-slate-300 min-h-[150px]"
                      placeholder="ระบุคำตอบของคุณ..."
                      value={answers[q.id] || ''}
                      onChange={(e) => handleAnswer(q.id, e.target.value)}
                    />
                  ) : (
                    <input 
                      type="text"
                      className="w-full bg-slate-50/50 border-2 border-slate-100 rounded-2xl p-6 focus:bg-white focus:border-indigo-600 focus:ring-0 transition-all text-lg placeholder:text-slate-300"
                      placeholder="ระบุคำตอบของคุณ..."
                      value={answers[q.id] || ''}
                      onChange={(e) => handleAnswer(q.id, e.target.value)}
                    />
                  )
                )}

                {['radio', 'checkbox', 'dropdown'].includes(q.type) && (
                  <div className="grid grid-cols-1 gap-3">
                    {q.options?.map((opt: any) => {
                      const optVal = opt.value ?? opt.id ?? opt.text ?? '';
                      const optText = opt.text ?? opt.label ?? opt.value ?? '';
                      const isMulti = (q.type as any) === 'checkbox' || q.type === 'multiple_choice';
                      const isChecked = isMulti
                        ? (answers[q.id] || []).includes(optVal)
                        : answers[q.id] === optVal;

                      return (
                        <button
                          key={opt.id || optVal}
                          onClick={() => {
                            if (isMulti) {
                              const current = answers[q.id] || [];
                              if (current.includes(optVal)) {
                                handleAnswer(q.id, current.filter((v: any) => v !== optVal));
                              } else {
                                handleAnswer(q.id, [...current, optVal]);
                              }
                            } else {
                              handleAnswer(q.id, optVal);
                            }
                          }}
                          className={`flex items-center gap-4 p-5 rounded-2xl border-2 transition-all text-left group/opt ${
                            isChecked
                              ? 'bg-indigo-50 border-indigo-600 text-indigo-900 shadow-md translate-x-1'
                              : 'bg-white border-slate-100 text-slate-600 hover:border-slate-300'
                          }`}
                        >
                          <div className={`w-6 h-6 border-2 flex items-center justify-center transition-all ${
                            isMulti ? 'rounded-lg' : 'rounded-full'
                          } ${
                            isChecked
                              ? 'bg-indigo-600 border-indigo-600 scale-110'
                              : 'border-slate-200 bg-white'
                          }`}>
                            <CheckCircle2 className={`w-4 h-4 text-white transition-opacity ${
                              isChecked ? 'opacity-100' : 'opacity-0'
                            }`} />
                          </div>
                          <span className="font-bold text-lg">{optText}</span>
                        </button>
                      );
                    })}
                  </div>
                )}

                {q.type === 'scale' && (
                  <div className="space-y-8 py-4">
                    <div className="flex justify-between items-center px-2">
                      {[...Array((q.maxScale || 10) - (q.minScale || 0) + 1)].map((_, i) => {
                        const val = (q.minScale || 0) + i;
                        return (
                          <button
                            key={i}
                            onClick={() => handleAnswer(q.id, val)}
                            className={`w-12 h-14 rounded-2xl border-2 flex flex-col items-center justify-center transition-all ${
                              answers[q.id] === val
                                ? 'bg-indigo-600 border-indigo-600 text-white shadow-xl scale-110'
                                : 'bg-slate-50 border-slate-100 text-slate-400 hover:border-slate-300 hover:text-slate-600'
                            }`}
                          >
                            <span className="text-xl font-black">{val}</span>
                          </button>
                        );
                      })}
                    </div>
                    <div className="flex justify-between text-xs font-black text-slate-400 uppercase tracking-widest px-1">
                      <span>{q.minLabel}</span>
                      <span>{q.maxLabel}</span>
                    </div>
                  </div>
                )}

                {((q.type as any) === 'matrix' || q.type === 'matrix_rating') && (
                  <div className="overflow-x-auto -mx-8 md:mx-0 bg-slate-50 rounded-3xl p-1">
                    <table className="w-full border-separate border-spacing-2">
                      <thead>
                        <tr>
                          <th className="p-4"></th>
                          {q.matrixCols?.map((col: any, cIdx: number) => {
                            const colText = typeof col === 'string' ? col : col?.text || col?.label || `ระดับ ${cIdx + 1}`;
                            return (
                              <th key={col?.id || cIdx} className="p-4 text-xs font-black text-slate-400 uppercase tracking-widest text-center">
                                {colText}
                              </th>
                            );
                          })}
                        </tr>
                      </thead>
                      <tbody>
                        {q.matrixRows?.map((row: any, rIdx: number) => {
                          const rowText = typeof row === 'string' ? row : row?.text || row?.label || `หัวข้อ ${rIdx + 1}`;
                          const rowKey = typeof row === 'string' ? row : row?.id || `r_${rIdx}`;
                          return (
                            <tr key={rIdx}>
                              <td className="p-4 font-bold text-slate-700 bg-white rounded-2xl shadow-sm border border-slate-100">{rowText}</td>
                              {q.matrixCols?.map((col: any, cIdx: number) => (
                                <td key={cIdx} className="p-2 text-center">
                                  <button
                                    onClick={() => {
                                      const current = answers[q.id] || {};
                                      handleAnswer(q.id, { ...current, [rowKey]: (q.matrixCols!.length - cIdx) });
                                    }}
                                    className={`w-12 h-12 rounded-full border-2 transition-all flex items-center justify-center ${
                                      (answers[q.id]?.[rowKey] === (q.matrixCols!.length - cIdx))
                                        ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg scale-110'
                                        : 'bg-white border-slate-100 text-slate-300 hover:border-slate-300 hover:text-slate-500'
                                    }`}
                                  >
                                    <div className="w-2.5 h-2.5 bg-current rounded-full" />
                                  </button>
                                </td>
                              ))}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {q.type === 'rating' && (
                  <div className="flex gap-4 py-4">
                    {[1, 2, 3, 4, 5].map(val => (
                      <button
                        key={val}
                        onClick={() => handleAnswer(q.id, val)}
                        className={`p-3 rounded-2xl transition-all ${
                          (answers[q.id] || 0) >= val ? 'text-yellow-400 scale-125' : 'text-slate-100'
                        }`}
                      >
                        <Star className="w-12 h-12 fill-current stroke-current stroke-2" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {/* Respondent Info Section (Optional) */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-slate-900 p-10 md:p-14 rounded-[3rem] shadow-2xl text-white space-y-10 relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -mr-20 -mt-20 group-hover:bg-indigo-500/20 transition-all duration-1000" />
            <div className="relative z-10 space-y-4 text-center max-w-xl mx-auto">
              <h3 className="text-3xl font-black tracking-tight">ข้อมูลผู้ให้ข้อมูล</h3>
              <p className="text-indigo-100/60 font-medium">กรุณาระบุข้อมูลส่วนบุคคลของท่าน เพื่อความถูกต้องในการสรุปผลเชิงวิเคราะห์ระดับหน่วยงาน (ข้อมูลของท่านจะถูกเก็บเป็นความลับ)</p>
            </div>
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { label: 'ชื่อ-นามสกุล', key: 'name', placeholder: 'ระบุชื่อของท่าน...', icon: '👤' },
                { label: 'หน่วยงาน / องค์กร', key: 'department', placeholder: 'เช่น อบจ.ระยอง / ประชาชน...', icon: '🏢' },
                { label: 'ตำแหน่ง', key: 'position', placeholder: 'ระบุตำแหน่งของท่าน...', icon: '💼' },
                { label: 'เบอร์โทรศัพท์ติดต่อ', key: 'phone', placeholder: 'ระบุเบอร์โทรสาร...', icon: '📞' }
              ].map((field) => (
                <div key={field.key} className="space-y-2">
                  <label className="text-xs font-black text-indigo-400 uppercase tracking-widest ml-1">{field.label}</label>
                  <div className="relative group/field">
                    <span className="absolute left-6 top-1/2 -translate-y-1/2 text-xl group-focus-within/field:scale-125 transition-transform">{field.icon}</span>
                    <input 
                      type="text"
                      placeholder={field.placeholder}
                      value={(respondentInfo as any)[field.key]}
                      onChange={(e) => setRespondentInfo({...respondentInfo, [field.key]: e.target.value})}
                      className="w-full bg-white/5 border-2 border-white/10 rounded-2xl pl-16 pr-6 py-5 focus:bg-white focus:text-slate-900 focus:border-indigo-500 focus:ring-0 transition-all font-bold placeholder:text-white/20"
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="relative z-10 pt-10 flex flex-col items-center">
              <button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="group relative px-14 py-6 bg-indigo-600 hover:bg-indigo-500 text-white rounded-[2rem] font-black text-2xl shadow-2xl shadow-indigo-600/40 transition-all active:scale-95 disabled:opacity-50 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                {isSubmitting ? (
                  <div className="flex items-center gap-4">
                    <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin" />
                    <span>กำลังส่งข้อมูล...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-4">
                    <Send className="w-7 h-7 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    <span>ส่งข้อมูลแบบสำรวจ</span>
                  </div>
                )}
              </button>
              <p className="mt-8 text-xs font-black text-white/30 uppercase tracking-[0.2em] flex items-center gap-3">
                <div className="w-8 h-[1px] bg-white/10" />
                Security Guaranteed by DDPM Rayong
                <div className="w-8 h-[1px] bg-white/10" />
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default SurveyPublicViewer;
