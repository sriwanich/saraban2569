import React, { useState, useEffect } from 'react';
import { 
  ClipboardCheck, Plus, Search, Filter, MoreVertical, 
  Eye, BarChart3, Edit, Trash2, Send, Copy, 
  ExternalLink, CheckCircle2, Clock, AlertCircle,
  FileSpreadsheet, FilePieChart, TrendingUp, Users,
  Layers, Settings2, Sparkles, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Survey, SurveySettings } from '../../../types/survey';
import SurveyEditor from './SurveyEditor';
import SurveyAnalytics from './SurveyAnalytics';

interface SurveyManagementViewProps {
  user: any;
  hasPermission: (key: string) => boolean;
}

const SurveyManagementView: React.FC<SurveyManagementViewProps> = ({ user, hasPermission }) => {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [activeView, setActiveView] = useState<'list' | 'editor' | 'analytics'>('list');
  const [selectedSurvey, setSelectedSurvey] = useState<Survey | null>(null);
  const [stats, setStats] = useState({
    totalSurveys: 0,
    totalViews: 0,
    totalResponses: 0,
    activeSurveys: 0
  });

  useEffect(() => {
    fetchSurveys();
    fetchStats();
  }, []);

  const fetchSurveys = async () => {
    try {
      const res = await fetch('/api/surveys');
      const data = await res.json();
      setSurveys(data);
    } catch (err) {
      console.error('Failed to fetch surveys:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/surveys/stats/overview');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  const handleCreateNew = () => {
    setSelectedSurvey(null);
    setActiveView('editor');
  };

  const handleEdit = (survey: Survey) => {
    setSelectedSurvey(survey);
    setActiveView('editor');
  };

  const handleAnalytics = (survey: Survey) => {
    setSelectedSurvey(survey);
    setActiveView('analytics');
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('คุณต้องการลบแบบสำรวจนี้ใช่หรือไม่? ข้อมูลการตอบกลับทั้งหมดจะถูกลบไปด้วย')) return;
    try {
      await fetch(`/api/surveys/${id}`, { method: 'DELETE' });
      setSurveys(surveys.filter(s => s.id !== id));
      fetchStats();
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const handleCopyLink = (id: string) => {
    const url = `${window.location.origin}/public/survey/${id}`;
    navigator.clipboard.writeText(url);
    alert('คัดลอกลิงก์แบบสำรวจแล้ว');
  };

  const filteredSurveys = surveys.filter(s => {
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         s.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || s.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  if (activeView === 'editor') {
    return (
      <SurveyEditor 
        survey={selectedSurvey} 
        user={user} 
        onClose={() => {
          setActiveView('list');
          fetchSurveys();
        }} 
      />
    );
  }

  if (activeView === 'analytics' && selectedSurvey) {
    return (
      <SurveyAnalytics 
        survey={selectedSurvey} 
        onClose={() => setActiveView('list')} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 p-4 md:p-8">
      {/* Header Section */}
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight flex items-center gap-3">
              <ClipboardCheck className="w-10 h-10 text-indigo-600" />
              SurveyKing Enterprise
            </h1>
            <p className="text-slate-500 mt-1 text-lg">ระบบจัดการแบบสำรวจและประเมินผลระดับองค์กรอัจฉริยะ</p>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleCreateNew}
              className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-semibold shadow-lg shadow-indigo-200 transition-all active:scale-95"
            >
              <Plus className="w-5 h-5" />
              สร้างแบบสำรวจใหม่
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { label: 'แบบสำรวจทั้งหมด', value: stats.totalSurveys, icon: Layers, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'กำลังเปิดรับข้อมูล', value: stats.activeSurveys, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { label: 'จำนวนการเข้าชม', value: stats.totalViews.toLocaleString(), icon: Eye, color: 'text-amber-600', bg: 'bg-amber-50' },
            { label: 'การตอบกลับทั้งหมด', value: stats.totalResponses.toLocaleString(), icon: Users, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-5"
            >
              <div className={`${stat.bg} ${stat.color} p-4 rounded-xl`}>
                <stat.icon className="w-8 h-8" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
                <h3 className="text-3xl font-bold text-slate-900 mt-0.5">{stat.value}</h3>
              </div>
            </motion.div>
          ))}
        </div>

        {/* List Section */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          {/* Controls */}
          <div className="p-6 border-b border-slate-100 bg-white/50 backdrop-blur-sm sticky top-0 z-10 flex flex-col md:flex-row gap-4 justify-between">
            <div className="flex flex-1 items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="ค้นหาชื่อแบบสำรวจหรือคำอธิบาย..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent rounded-xl transition-all"
                />
              </div>
              <select 
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-4 py-3 bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-indigo-500 rounded-xl transition-all font-medium text-slate-600"
              >
                <option value="all">ทุกหมวดหมู่</option>
                <option value="satisfaction">ความพึงพอใจ</option>
                <option value="readiness">ความพร้อม</option>
                <option value="general">ทั่วไป</option>
              </select>
            </div>
          </div>

          {/* List Table */}
          <div className="overflow-x-auto">
            {loading ? (
              <div className="py-20 flex flex-col items-center justify-center text-slate-400 gap-4">
                <div className="w-12 h-12 border-4 border-indigo-600/20 border-t-indigo-600 rounded-full animate-spin"></div>
                <p className="font-medium">กำลังโหลดข้อมูลแบบสำรวจ...</p>
              </div>
            ) : filteredSurveys.length > 0 ? (
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50/50">
                    <th className="px-6 py-4 text-sm font-semibold text-slate-600 first:pl-8">รายละเอียดแบบสำรวจ</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-600">สถานะ</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-600">สถิติ (ชม/ตอบ)</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-600">แก้ไขล่าสุด</th>
                    <th className="px-6 py-4 text-sm font-semibold text-slate-600 text-right pr-8">จัดการ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSurveys.map((survey) => (
                    <motion.tr 
                      key={survey.id}
                      layout
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="group hover:bg-slate-50/80 transition-colors"
                    >
                      <td className="px-6 py-5 first:pl-8">
                        <div className="flex flex-col">
                          <span className="font-bold text-slate-900 text-lg group-hover:text-indigo-600 transition-colors">{survey.title}</span>
                          <span className="text-slate-500 text-sm mt-1 line-clamp-1">{survey.description}</span>
                          <div className="flex items-center gap-2 mt-2">
                            <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[11px] font-bold uppercase tracking-wider">
                              {survey.categoryLabel}
                            </span>
                            <span className="text-slate-400 text-[11px] font-medium">• {survey.department}</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5">
                        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ring-1 ring-inset ${
                          survey.status === 'published' 
                            ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20' 
                            : survey.status === 'closed'
                            ? 'bg-rose-50 text-rose-700 ring-rose-600/20'
                            : 'bg-slate-50 text-slate-700 ring-slate-600/20'
                        }`}>
                          <div className={`w-1.5 h-1.5 rounded-full ${
                            survey.status === 'published' ? 'bg-emerald-500 animate-pulse' : survey.status === 'closed' ? 'bg-rose-500' : 'bg-slate-400'
                          }`} />
                          {survey.status === 'published' ? 'กำลังเปิดใช้งาน' : survey.status === 'closed' ? 'ปิดรับข้อมูลแล้ว' : 'ร่างต้นฉบับ'}
                        </span>
                      </td>
                      <td className="px-6 py-5">
                        <div className="flex items-center gap-4">
                          <div className="flex flex-col">
                            <span className="text-slate-900 font-bold">{survey.viewCount}</span>
                            <span className="text-slate-400 text-[10px] uppercase font-bold">Views</span>
                          </div>
                          <div className="w-px h-6 bg-slate-200" />
                          <div className="flex flex-col">
                            <span className="text-indigo-600 font-bold">{survey.responseCount}</span>
                            <span className="text-slate-400 text-[10px] uppercase font-bold">Responses</span>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-5 text-sm text-slate-500 font-medium">
                        {new Date(survey.updatedAt).toLocaleDateString('th-TH', { 
                          day: 'numeric', month: 'short', year: 'numeric' 
                        })}
                      </td>
                      <td className="px-6 py-5 text-right pr-8">
                        <div className="flex items-center justify-end gap-2">
                          <button 
                            onClick={() => handleAnalytics(survey)}
                            className="p-2.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                            title="ดูสถิติและรายงาน"
                          >
                            <BarChart3 className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => handleEdit(survey)}
                            className="p-2.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                            title="แก้ไข"
                          >
                            <Edit className="w-5 h-5" />
                          </button>
                          <button 
                            onClick={() => handleCopyLink(survey.id)}
                            className="p-2.5 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-all"
                            title="คัดลอกลิงก์"
                          >
                            <Copy className="w-5 h-5" />
                          </button>
                          <div className="w-px h-6 bg-slate-200 mx-1" />
                          <button 
                            onClick={() => handleDelete(survey.id)}
                            className="p-2.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                            title="ลบ"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="py-20 flex flex-col items-center justify-center text-slate-400 bg-slate-50/30">
                <div className="p-6 bg-white rounded-full shadow-sm mb-4">
                  <ClipboardCheck className="w-16 h-16 text-slate-200" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">ไม่พบแบบสำรวจ</h3>
                <p className="text-slate-500 mt-1">เริ่มต้นสร้างแบบสำรวจแรกของคุณด้วยระบบอัจฉริยะ</p>
                <button 
                  onClick={handleCreateNew}
                  className="mt-6 px-6 py-3 bg-white border border-slate-200 text-indigo-600 font-bold rounded-xl hover:bg-indigo-50 transition-all shadow-sm"
                >
                  <Plus className="w-5 h-5 inline-block mr-2" />
                  สร้างตอนนี้
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SurveyManagementView;
